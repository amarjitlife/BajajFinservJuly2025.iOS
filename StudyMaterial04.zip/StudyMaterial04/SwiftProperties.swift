
//____________________________________________________________________________

struct FixedLengthRange {
	var firstValue: Int
	let length: Int
}

var rangeOfThreeItems = FixedLengthRange( firstValue: 0, length: 3 )

print( rangeOfThreeItems )
print( rangeOfThreeItems.firstValue )
rangeOfThreeItems.firstValue = 66

print( rangeOfThreeItems )
print( rangeOfThreeItems.firstValue )

let rangeOfThreeItemsAgain = FixedLengthRange( firstValue: 0, length: 3 )
print( rangeOfThreeItemsAgain )
// rangeOfThreeItemsAgain.firstValue = 66
// print( rangeOfThreeItemsAgain )

//____________________________________________________________________________

struct Point {
	var x = 0.0, y = 0.0
}

struct Size {
	var width = 0.0, height = 0.0
}

struct Rectangle {
	// Member Properties
	var origin 	= Point()
	var size 	= Size()
	// Member Function
	func getCenter() -> Point {
		let cx = origin.x + ( size.width / 2 )
		let cy = origin.y + ( size.height / 2 )
		return Point( x: cx, y: cy )
	}

	mutating func setCenter( newCenter: Point ) {
		origin.x = newCenter.x - ( size.width / 2 )
		origin.y = newCenter.y - ( size.height / 2 )
	}
}


var rectangle = Rectangle( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )

print( rectangle )
print( rectangle.origin )
print( rectangle.size )
print( rectangle.getCenter() )


//____________________________________________________________________________


struct RectangleAgain {
	// Member Properties : Stored Member Properties
	var origin 	= Point()
	var size 	= Size()

	// Member Properties : Computed Member Properties
	var center : Point {	
		get {
			let cx = origin.x + ( size.width / 2 )
			let cy = origin.y + ( size.height / 2 )
			return Point( x: cx, y: cy )
		}

		set( newCenter ) {
			let cx = newCenter.x - ( size.width / 2 )
			let cy = newCenter.y - ( size.height / 2 )
			origin = Point( x: cx, y: cy ) 
		}
	}
}

var rectangle1 = RectangleAgain( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )
print( rectangle1 )
print( rectangle1.size )
print( rectangle1.origin )
print( rectangle1.center ) // rectangle1.getCenter()
// rectanlge1.setCenter(  Point( x: 50.0, y: 50.0 ) )
rectangle1.center = Point( x: 50.0, y: 50.0 ) 
print( rectangle1.origin )
print( rectangle1.center )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

