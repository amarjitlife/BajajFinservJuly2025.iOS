
//____________________________________________________________________________

struct Resolution {
	// Mutable Members Properties
	var width 	= 0 		// Default Values
	// let height	= 0
	var height	= 0
}

// Structure Object Immutable
let someResolution = Resolution()
print( someResolution )

// someResolution.width  = 99
// someResolution.height = 11
// print( someResolution )

// Structure Object Mutable
var someResolution1 = Resolution()
print( someResolution1 )

someResolution1.width 	= 99
someResolution1.height 	= 11

print( someResolution1 )

//____________________________________________________________________________

// Arugments To Functions Are Pass As Immutable
func doChangeResolution( resolution: Resolution ) {
	// error: cannot assign to property: 'resolution' is a 'let' constant
	// resolution.width 	= 999
	// resolution.height 	= 111
}

func doChangeResolutionAgain( resolution: inout Resolution ) {
	// error: cannot assign to property: 'resolution' is a 'let' constant
	resolution.width 	= 999
	resolution.height 	= 111
}

var someResolution2 = Resolution( width: 10, height: 10 )

print( someResolution2 )
// doChangeResolution( resolution: someResolution2 )
doChangeResolutionAgain( resolution: &someResolution2 )
print( someResolution2 )

//____________________________________________________________________________
// In Swift Value Types
//		Structures Are Value Types
//		Arrays, Sets, Dictionaries Are Also Value Types
//		Enums Are Also Value Types
//		Int, String, Double, Float Value Types

// In Swift Reference Types
//		Clojures and Classes Are Reference Type

var someResolution3 = Resolution( width: 20, height: 20 )

var someResolution4 = someResolution3  // Value Assignment

print( someResolution3 )
print( someResolution4 )

someResolution3.width  = 99
someResolution3.height = 99
print( someResolution3 )
print( someResolution4 )

// Resolution(width: 20, height: 20)
// Resolution(width: 20, height: 20)
// Resolution(width: 99, height: 99)
// Resolution(width: 20, height: 20)

//__________________________________________

// Value Type
enum CompassPoint {
    case North, South, East, West
}

var currentDirection = CompassPoint.West
let rememberedDirection = currentDirection // Value Assignment

print( currentDirection )
print( rememberedDirection )

currentDirection = .North

print( currentDirection )
print( rememberedDirection )

//__________________________________________

var numbers: [Int] = [10, 20, 30, 40, 50]
var numbersCopy = numbers  // Value Assignment

print( numbers )
print( numbersCopy )

for (index, _) in numbers.enumerated() {
	numbers[index] = 99
}

print( numbers )
print( numbersCopy )

//__________________________________________

var numbersSet: Set = [1,3,5,7,9]
var numbersSetCopy = numbersSet  // Value Assignment

print( numbersSet )
print( numbersSetCopy )

numbersSet.insert( 10 )
print( numbersSet )
print( numbersSetCopy )

//__________________________________________

var airports: Dictionary<String, String> = ["TYO":"Tokyo", "DUB":"Dublin"]
var airportsCopy = airports // Value Assignment

print( airports )
print( airportsCopy )

airports["TYO"] = "Tokyo City"
print( airports )
print( airportsCopy )

//__________________________________________
// In Swift Reference Types
//		Clojures and Classes Are Reference Type

func makeIncrementor(forIncrement amount: Int) -> () -> Int { // Enclosing/Outside Context
    var runningTotal = 0 // Local Variable
    // Local Function : Function Defined Inside A Function 
    func incrementor() -> Int { // Enclosed/Inside Context
        runningTotal += amount
        return runningTotal
    }
    return incrementor
}

let incrementByTen: () -> Int = makeIncrementor(forIncrement: 10)

let incrementByTenCopy = incrementByTen // Reference Assignmen

print( incrementByTen() )
print( incrementByTen() ) 

print( incrementByTenCopy() )
print( incrementByTenCopy() )

//____________________________________________________________________________
// In Swift Reference Types
//		Clojures and Classes Are Reference Type

class VideoMode {
	var resolution = Resolution()
	var frameRate  = 0.0
	var name: String = "Unknown"
}

var someVideoMode = VideoMode()
var someVideoModeCopy = someVideoMode // Reference Assignment

print( someVideoMode.resolution, someVideoMode.frameRate, someVideoMode.name )
print( someVideoModeCopy.resolution, someVideoModeCopy.frameRate, someVideoModeCopy.name )

someVideoMode.frameRate = 60
someVideoMode.name = "HD"

print( someVideoMode.resolution, someVideoMode.frameRate, someVideoMode.name )
print( someVideoModeCopy.resolution, someVideoModeCopy.frameRate, someVideoModeCopy.name )

// Resolution(width: 0, height: 0) 0.0 Unknown
// Resolution(width: 0, height: 0) 0.0 Unknown
// Resolution(width: 0, height: 0) 60.0 HD
// Resolution(width: 0, height: 0) 60.0 HD

if someVideoMode === someVideoModeCopy {
	print("Equal: References Are Pointing To Same Object ")
} else {
	print("Not Equal")	
}

// Pointers
// If you have experience with C, C++, or Objective-C, 
// you may know that these languages use pointers to refer to addresses in memory. 

//	A Swift constant or variable that refers to an instance of some reference type 
//	is similar to a pointer in C, but isn’t a direct pointer to an address in memory, 
//	and doesn’t require you to write an asterisk (*) to indicate that 
//	you are creating a reference. 

//	Instead, these references are defined like any other constant or variable in Swift. 
//	The Swift standard library provides pointer and buffer types that you can 
//	use if you need to interact with pointers directly

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codeshare.io/G6V4JY
// https://codeshare.io/G6V4JY
// https://codeshare.io/G6V4JY

