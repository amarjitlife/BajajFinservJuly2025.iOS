//_________________________________________________________________


print("Hello World! Welcome To Swift!!!")

//_________________________________________________________________

// Implicit Types Decisions
//		1. Type Inferrencing ( RHS )
//		2. Type Binding ( LHS ) : inferred Type Is Binded To LHS

// Types Decisions
//		1. Compile Time
//				C/C++/Java/Kotlin/Swift etc.
//		2. Run Time
//				JavaScript, Python, Ruby etc.

// Mutable State
var myVariable = 99
print( myVariable )


myVariable = 100
print( myVariable )

// Immutable State
let myConstant = 11
print( myConstant )
// myConstant = 88 
// error: cannot assign to value: 'myConstant' is a 'let' constant
// print( myConstant )

let someNumber1 = 70
// Explicit Types 
//					Type Annotation
let someNumberAgain1: Int = 70
print( someNumber1 )
print( someNumberAgain1 )

let someNumber2 = 99.99
let someNumberAgain2: Double = 99.99

print( someNumber2 )
print( someNumberAgain2 )

let someNumber3: Float = 99.99
print( someNumber3 )

//_________________________________________________________________
// String Interpolation

let apples = 3
let oranges = 5

// String Interpolation
let appleSummary = "Apples Count: \(apples)"
let fruitsSummary = "Fruits Count: \(apples + oranges) "
print( appleSummary )
print( fruitsSummary )

let pi: Float = 3.1415
let name = "Gabbar Singh"
let piGabbar = "\(name) Likes Pi \(pi)"
print( piGabbar )

//_________________________________________________________________
var shoppingList = ["Apple Watch", "Bread", "iPhone", "Charger", "Pudi" ]
print( shoppingList )

shoppingList.append( "Macbook Pro" )
print( shoppingList )

let shoppingListAgain = ["Apple Watch", "Bread", "iPhone", "Charger", "Pudi" ]
print( shoppingListAgain )

shoppingListAgain.append( "Macbook Pro" ) // error: cannot use mutating member on immutable value:
print( shoppingListAgain )


print( shoppingList[0] )
print( shoppingList[1] )

// print( shoppingList[-1] ) 	// Fatal error: Index out of range
// print( shoppingList[5] ) 	// Fatal error: Index out of range

for shop in shoppingList {
	print( shop )
}

var teamScore = 0
let scores = [10, 20, 419, 300, 200 ]
for score in scores {
	if score > 50 {
		teamScore = teamScore + 3
	} else {
		teamScore = teamScore + 1
	}
}
print( teamScore )

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________