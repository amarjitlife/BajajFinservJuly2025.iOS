
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

//____________________________________________

void playWithCString() {
	char greeting[] = "Good Morning!";
	printf("\n");
	for( int i = 0 ; greeting[i] != '\0' ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	// Well Behaving Programmer: Respect Ranges
	printf("\n");
	for( int i = 0 ; i < 13 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	printf("\n");
	for( int i = -10 ; i < 20 ; i++ ) {
		// // if ( i > 0 && i < greeting.length() ) { 
		// 	printf(" %c ", greeting[i] );
		// }
	}	
}

//____________________________________________
// BAD CODE

int sum_bad( int a, int b ) {
	return a + b;
}

//____________________________________________
// GOOD CODE

int sum_good( int a, int b ) {
	int result = 0;
	if (( ( b > 0 ) && a > (INT_MAX - b) ) ||
	    ( ( b < 0 ) && a < (INT_MIN - b) ) ) {
		printf("Can't Calculate Sum For Given a And b");
		exit( 1 ); // Throwing Exception
	} else {
		result = a + b;
		return result;
	}
}

//____________________________________________

int sum( int a, int b) { return a + b; }
int sub( int a, int b) { return a - b; }

// Polymorphic Function
int calculator( int a, int b, int (*operation)( int, int ) ) {
	return operation( a, b );
}

void playWithCalculator() {
	int x = 200, y = 100;
	int result = 0;

	result = calculator( x, y, sum );
	printf("\nResult: %d", result );

	result = calculator( x, y, sub );
	printf("\nResult: %d", result );
}

//____________________________________________

enum PlanetAgain {
	MERCURY = 1, VENUS, EARTH, MARS
};

void playWithEnums() {
	enum PlanetAgain planet = MERCURY;
	printf("\nEnum Value: %d", planet );

	planet = EARTH;
	printf("\nEnum Value: %d", planet );

	int some = 99;
	printf("\nValue: %d", some);

	some = planet;
	printf("\nValue: %d", some);

	planet = 777;
	printf("\nValue: %d", planet);	
}


//____________________________________________

int doSomething(int a, int b) {
	printf("\nDoing Something: Sum = %d", a + b );
	return 99;
}

void playWithDoSomething() {
	int x = 200, y = 333;

	int (*something)(int, int);
	something = doSomething;

	int result = something( x, y );
	printf("\nResult : %d ", result );
}

// Function: playWithDoSomething
// Doing Something: Sum = 533
// Result : 99

//____________________________________________
//____________________________________________
//____________________________________________

int main() {
	// printf("\n\nFunction: playWithCString");
	// playWithCString();

	printf("\n\n");
	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction: playWithEnums");
	playWithEnums();

	printf("\n\nFunction: playWithDoSomething");
	playWithDoSomething();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");	
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}
