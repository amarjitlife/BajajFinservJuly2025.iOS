//
//  ViewController.swift
//  TabViewController
//
//  Created by Amarjit Singh on 31/05/24.
//

import UIKit

class ViewController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        self.tabBar.backgroundColor = UIColor.systemYellow
        
        // Create Tab one
        let tabOne = TabOneViewController()
        let tabOneBarItem = UITabBarItem(
            title: "Tab 01",
            image: UIImage(named: "defaultImage.png"),
            selectedImage: UIImage(named: "selectedImage.png"))
        tabOne.tabBarItem = tabOneBarItem
        
        // Create Tab two
        let tabTwo = TabTwoViewController()
        let tabTwoBarItem2 = UITabBarItem(
            title: "Tab 02",
            image: UIImage(named: "defaultImage2.png"),
            selectedImage: UIImage(named: "selectedImage2.png"))
        
        tabTwo.tabBarItem = tabTwoBarItem2
        self.viewControllers = [tabOne, tabTwo]
    }
    
    // UITabBarControllerDelegate method
    func tabBarController(
        _ tabBarController: UITabBarController,
        didSelect viewController: UIViewController) {
        print("Selected \(viewController.title!)")
    }
}

//Commenting Generated Code
//import UIKit
//
//class ViewController: UIViewController {
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do any additional setup after loading the view.
//    }
//}
//
