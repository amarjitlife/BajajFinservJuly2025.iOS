//
//  TabTwoViewController.swift
//  TabViewController
//
//  Created by Amarjit Singh on 31/05/24.
//

//import Foundation

import UIKit

class TabTwoViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set the view's background color to green
        self.view.backgroundColor = UIColor.cyan
        // Set the title for the tab
        self.title = "Tab 02"
    }
}
