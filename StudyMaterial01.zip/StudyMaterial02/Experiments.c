
#include <stdio.h>

//____________________________________________

void playWithCString() {
	char greeting[] = "Good Morning!";
	printf("\n");
	for( int i = 0 ; greeting[i] != '\0' ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	// Well Behaving Programmer: Respect Ranges
	printf("\n");
	for( int i = 0 ; i < 13 ; i++ ) {
		printf(" %c ", greeting[i] );
	}

	printf("\n");
	for( int i = -10 ; i < 20 ; i++ ) {
		if ( i > 0 && i < greeting.length() ) { 
			printf(" %c ", greeting[i]; );
		}
	}	
}

//____________________________________________
// BAD CODE

int sum_bad( int a, int b ) {
	return a + b;
}

//____________________________________________
// GOOD CODE

int sum( int a, int b ) {
	int result = 0;
	if (( ( b > 0 ) && a > (INT_MAX - b) ) ||
	    ( ( b < 0 ) && a < (INT_MIN - b) ) ) {
		printf("Can't Calculate Sum For Given a And b");
		exit( 1 ); // Throwing Exception
	} else {
		result = a + b;
		return result;
	}
}

//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________
//____________________________________________

int main() {
	printf("\n\nFunction: playWithCString");
	playWithCString();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");	
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}
