
//_________________________________________________________________

// Mutable State
var myVariable = 99
print( myVariable )


myVariable = 100
print( myVariable )

// Immutable State
let myConstant = 11
print( myConstant )

var x = 0.0, y = 0.0, z = 0.0, u = 99
print( x, y, z, u )

// let xx: Int
// let yy: String
// print( xx ) //  error: constant 'xx' used before being initialized
// print( yy )

// BAD PRACTICE
// let xx: Int? = nil
// let yy: String? = nil
// print( xx ) 
// print( yy )

let xx: Int
// code...
xx = 11
// code...
print(xx)
// xx = 22
print(xx)

let welcomeMessage: String
welcomeMessage = "Hello World!"
print( welcomeMessage )

var someString: String?
someString = nil
// print( someString )
print( someString ?? "Unknown" )
someString = "Something"
print( someString ?? "Unknown" )

//_________________________________________________________________

let pi = 3.1415
print( pi )

let π = 3.1415
print( π )

let नमस्ते = "Namaskaraam!!!"
print( नमस्ते )

let नमस्कार = "नमस्कार"
print( नमस्कार )

let helloKorean = "안녕하세요"
print( helloKorean )

let 안녕하세요 = "Korean Hello!!!"
print( 안녕하세요 )

let வணக்கம் = "Vanakam In Tamil: வணக்கம்"
print( வணக்கம் )

let dogCow = "🐶🐮"
print( dogCow )

let 🐶🐮 = "Dog and Cow!"
print( 🐶🐮 )

//_________________________________________________________________

var a: Int8 = 127
let b: Int8 = 10
// In swift Operators Are Overflow/Underflow Aware
// a = a + b // Program crashed: Illegal instruction
// print( a )
a = a &+ b
print( a )

let c: Int16 = 11
// Swift Is Strictly Typed Language
// a = a + c // error: cannot convert value of type 'Int16' to expected argument type 'Int8'
// Explicity Conversion Required
//		Making Your Intension Clear
a = a + Int8( c )
print( a )

let pi1 = 3.1415
print( pi1 )
// Cpompiler Optimisation: Constant Folding
let anotherPi = 3 + 0.1415
print( anotherPi )

let three = 3
let piFraction = 0.1415
// error: binary operator '+' cannot be applied to operands of type 'Int' and 'Double'
// let piAgain = three + piFraction 
let piAgain = Double( three ) + piFraction 
print( piAgain )

//_________________________________________________________________
let some1 = 17
let some2 = 0b10001
let some3 = 0o21
let some4 = 0x11
print( some1, some2, some3, some4 )

let some11: Int = 17
let some21: Int = 0b10001
let some31: Int = 0o21
let some41: Int = 0x11
print( some11, some21, some31, some41 )

//_________________________________________________________________
// Alias means Nickname
typealias AudioSample = UInt16

var audioAmplitude: AudioSample = 90
print( audioAmplitude )

//_________________________________________________________________

let allowedInside = true
let notallowedInside = false

let allowedInsideAgain: Bool = true

//_________________________________________________________________

let ii = 11

// error: type 'Int' cannot be used as a boolean; test for '!= 0' instead
// if ( ii ) {
if ( ii == 11 ) {
	print("Oyee Hoye")
} else {
	print("Ballee Balleee")
}

//_________________________________________________________________

//: ## Tuples
let http404Error = (404, "Not Found")

// Tuple Unpacking/Decluttering
let (statusCode, statusMessage) = http404Error
print("The status code is \(statusCode)")
print("The status message is \(statusMessage)")

let (statusCodeAgain, _) = http404Error

// Named Tuple
let http404ErrorAgain = (status: 404, message: "Not Found")

print( http404Error.0, http404Error.1 )
print( http404ErrorAgain.status, http404ErrorAgain.message )

//_________________________________________________________________

let possibleNumber = "1234ABC"
let convertedNumber = Int( possibleNumber )
// let convertedNumber: Int? = Int( possibleNumber )

print( convertedNumber ) // Optional(1234)

// Handling Nothingess
if convertedNumber != nil {
	print( convertedNumber! ) // Unwrapping
} else {
	print("Nothingness Found!")
}

// Swift Is Idiomatic Langauge
// if let Idioms
if let actualNumber = Int(possibleNumber) {
	print(actualNumber)
} else {
	print("Nothingness Found!")	
}

// Compiler Will Generate Following Code For Above Idiom
let temporary = Int( possibleNumber )
if temporary != nil  {
	let actualNumber = temporary!
	print(actualNumber)
} else {
	print("Nothingness Found!")	
}

// ?? Means Followed by Default Value On nil
let something = convertedNumber ?? 777
// Compiler Will Generate Follwoing Code
// if convertedNumber == nil {
// 	something = 777
// }
print( something )

if let firstNumber = Int("44"), let secondNumber = Int("99"), firstNumber < secondNumber {
	print("\(firstNumber) < \(secondNumber)")
} else {
	print("Nothingness Found!")	
}

// Compiler Will Generate Following Code For Above Idiom
let temporary1 = Int( "44" )
let temporary2 = Int( "99" )
if temporary1 != nil && temporary2 != nil {
	let firstNumber = temporary1!
	let secondNumber = temporary2!
	if firstNumber < secondNumber {
		print("\(firstNumber) < \(secondNumber)")
	}
} else {
	print("Nothingness Found!")	
}


if var actualNumber = Int(possibleNumber) {
	actualNumber = actualNumber + 10
	print(actualNumber)
} else {
	print("Nothingness Found!")	
}

//_________________________________________________________________

let name = "world"
if name == "world" {
    print("hello, world")
} else {
    print("I'm sorry \(name), but I don't recognize you")
}

var result: Bool

result = (1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" are not compared
print( result )

result = (3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
print( result )

result = (4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"
print( result )

result = ("blue", -1) < ("purple", 1)        // OK, evaluates to true
print( result )

// ("blue", false) < ("purple", true)  // Error because < can't compare Boolean values
// error: binary operator '<' cannot be applied to two '(String, Bool)' operands

//_________________________________________________________________


let contentHeight = 50
let hasHeader = false

let rowHeight = contentHeight + ( (hasHeader) ? 50 : 20 )
print( rowHeight )

var choiceValue = ( hasHeader ? 50 : (contentHeight == 40) ? 10 : 100  )
print("Choice Value Using Ternary Operator: ", choiceValue)

if hasHeader {
    choiceValue = 50
} else if ( contentHeight == 40 ) {
    choiceValue = 10
} else {
    choiceValue = 100
}
print("Choice Value Using if-else Construct: ", choiceValue)

if hasHeader {
    choiceValue = 50
} else {
    choiceValue = (contentHeight == 40) ? 10 : 100
}
print("Choice Value Using if-else+Ternary: ", choiceValue)

let rowHeight1 = contentHeight + choiceValue
print(rowHeight1)

//_________________________________________________________________


// Range Operators
// The Closed Range Operator
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

// The Half-Closed Range Operator
let names0 = ["Anna", "Alex", "Brian", "Jack"]
let count = names0.count

for i in 0..<count {
    print("Person \(i + 1) is called \(names0[i])")
}

let names = [ "Ding", "Dong", "King", "Kong", "Ting", "Tong" ]
let namesCount = names.count
print(names)
print( namesCount )

print()
for i in 0..<namesCount {
    print("Person at \(i) is: \(names[i])")
}

print()
for name in names {
    print("Person Name: \(name)")
}

print()
for name in names[2...] {
    print("Person Name: \(name)")
}

print()
for name in names[...2] {
    print("Person Name: \(name)")
}

print()
for name in names[..<2] {
    print("Person Name: \(name)")
}

print()
for name in names[2...5] {
    print("Person Name: \(name)")
}


//_________________________________________________________________

let range1 = 1...10
print(range1)
for value in range1 {
    print(value)
}

let range2 = ...10
print(range2)
// Runtime Error: Not provided starting value
// for value in range2 {
//     print(value)
// }

let range3 = 1...
print(range3)
// Infinite Loop
// for value in range3 {
//     print(value)
//}

for value in range3 {
    if value == 100 { break }
    print(value)
}

//_________________________________________________________________


// Logical Operators
let allowedEntry = false
if !allowedEntry {
    print("ACCESS DENIED")
}

let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome")
} else {
    print("ACCESS DENIED")
}

if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

