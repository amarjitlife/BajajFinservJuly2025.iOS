//____________________________________________________________________________
//
// DAY 01
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT
		Read Types an Expression Chapter
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 02
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Read Pointers and Arrays Chapter 
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 03
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Read Pointers and Arrays Chapter 
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

ASSIGNMENT A4: READING AND REVISION ASSIGNMENTS
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/collectiontypes/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

https://github.com/amarjitlife/BajajFinservJuly2025.iOS
https://github.com/amarjitlife/BajajFinservJuly2025.iOS
https://github.com/amarjitlife/BajajFinservJuly2025.iOS

//____________________________________________________________________________

amarjitlife@gmail.com

SUBJECT: BajajFinserv iOS BATCH 02 QUIZ

IN BODY
	MENTION YOUR FULL NAME
	COPY YOUR ALL ANSWERS

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________



