
class Human {
	int id;
	String name;

	Human( int id, String name ) {
		this.id = id;
		this.name = name;
	}
}

public class Experiments {

//______________________________________________________________________

	public static void swap(String a, String b) {
		String temp = null ;
		temp = a;
		a = b;
		b = temp;
	}

	public static void playWithSwap() {
		String first = "Hello";
		String second = "Byee";

		System.out.println( first );
		System.out.println( second );
		swap( first, second );
		System.out.println( first );
		System.out.println( second );
	}

//______________________________________________________________________

	public static void doChange( Human h ) {
		h = new Human( 100 , "Good Gabbar Singh");
	}

	public static void playWithDoChange() {
		Human bg = new Human( 420, "Gabbar Singh" );
		System.out.println( bg.name );
		doChange( bg );
		System.out.println( bg.name );
	}

// Function: playWithDoChange
// Gabbar Singh
// Gabbar Singh

//______________________________________________________________________

	public static void doChangeAgain( Human h ) {
		h.name = "Gabbar Singh Very Big Daku";
		h.id = 50000;
	}

	public static void playWithDoChangeAgain() {
		Human h = new Human( 420, "Gabbar Singh" );
		System.out.println( h.name );
		doChangeAgain( h );
		System.out.println( h.name );
	}

// Function: playWithDoChangeAgain
// Gabbar Singh
// Gabbar Singh Very Big Daku

//______________________________________________________________________

	public static void main( String[] args ) {
		System.out.println("\n\nFunction: playWithSwap");
		playWithSwap();

		System.out.println("\n\nFunction: playWithDoChange");
		playWithDoChange();

		System.out.println("\n\nFunction: playWithDoChangeAgain");
		playWithDoChangeAgain();
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");		
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
	}
}

