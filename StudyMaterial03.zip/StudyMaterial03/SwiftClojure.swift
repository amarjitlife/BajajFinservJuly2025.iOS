

var names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backwards(s1: String, s2: String) -> Bool {
    return s1 > s2
}

var reversed: () = names.sort(by: backwards)

// Closure Expression Syntax
reversed = names.sort( by: { (s1:String, s2: String) -> Bool in return s1 > s2 } )

// Inferring Type from from Context
reversed = names.sort( by: { s1, s2 in return s1 > s2 })

// Implicit returns from Single-Expression Closures
reversed = names.sort( by: { s1, s2 in s1 > s2 })

// Shorthand Argument Names
reversed = names.sort( by: { $0 > $1 })

// Operator Functions
reversed = names.sort( by: >)
// Trailing Closures

func someFunctionThatTakesAClosure(closure: () -> () ) {
    
}

someFunctionThatTakesAClosure( closure: {} )
someFunctionThatTakesAClosure() { // Trailing Lamba Syntax
    
}


//____________________________________________________________________________

let digitNames: [Int : String] = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4:"Four", 5: "Five", 6:"Six", 7: "Seven", 8: "Eight", 9: "Nine"]
let numbers = [16, 58, 510]

let strings = numbers.map {
    (number) -> String in
    var number = number
    var output = ""
    while number > 0 {
        output = digitNames[number % 10]! + output
        number /= 10
    }
    return output
}

print( digitNames )
print( numbers )
print( strings )

// [3: "Three", 8: "Eight", 2: "Two", 0: "Zero", 7: "Seven", 4: "Four", 9: "Nine", 5: "Five", 1: "One", 6: "Six"]
// [16, 58, 510]
// ["OneSix", "FiveEight", "FiveOneZero"]

//____________________________________________________________________________

func doChange( numbers: [Int] ) {
    var numbers = numbers
    for (index, _) in numbers.enumerated() {
        numbers[ index ] = 99 
    }
}

func doChangeAgain( numbers: inout [Int] ) {
    for (index, _) in numbers.enumerated() {
        numbers[ index ] = 99 
    }
}

func playWithDoChange() {
    var numbers = [10, 20, 30, 40, 50, 60]
    print( numbers )
    doChange( numbers: numbers )
    print( numbers )    

    doChangeAgain( numbers: &numbers )
    print( numbers )    
}

playWithDoChange()

//____________________________________________________________________________

func makeIncrementor(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    // Local Function : Function Defined Inside A Function 
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
}

let incrementByTen = makeIncrementor(forIncrement: 10)

print( incrementByTen() )
print( incrementByTen() ) 
print( incrementByTen() )

let incrementBySeven = makeIncrementor(forIncrement: 7)
print( incrementBySeven() )
print( incrementBySeven() )

print( incrementByTen() )
print( incrementByTen() )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________




