
//__________________________________________________________

fun hello() {
	println("Good Morning!")
}

fun sayhello(toName: String ) {
	println("Good Morning! $toName")
}

fun playWithHello() {
	val some = hello()
	println( some )

	sayhello( "Gabbar Singh" )
	sayhello( toName = "Gabbar Singh" )	
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

fun main() {
	println("\nFunction: playWithHello")
	playWithHello()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

