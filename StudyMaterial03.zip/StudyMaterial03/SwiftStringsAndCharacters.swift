
// Strings and Characters
//_________________________________________________________________

let someString = "Some tring literal value"
print( someString )

// Initializing an Empty Strings
var emptyString = ""
var anotherEmpyString = String()
if emptyString.isEmpty {
    print("Nothing to see here")
}

if anotherEmpyString.isEmpty {
    print("Nothing to see here")
}

//_________________________________________________________________

// String mutability
var variableString = "Horse"
print( variableString )

variableString += " and carriage"
print( variableString )

let constantString = "Highlander"
print( constantString )

// constantString += " and another Highlander" // There can be only one

//_________________________________________________________________

let नमस्ते = "Namaskaraam!!!"
print( नमस्ते )

let नमस्कार = "नमस्कार"
print( नमस्कार )


let 안녕하세요 = "Korean Hello!!!"
print( 안녕하세요 )

let வணக்கம் = "Vanakam In Tamil: வணக்கம்"
print( வணக்கம் )

let dogCow = "🐶🐮"
print( dogCow )

for character in dogCow {
	print( character )
}

let helloKorean = "안녕하세요"
print( helloKorean )
print( "String Length: ", helloKorean.count )

for character in helloKorean {
	print( character )
}

let வணக்கம்1 = "வணக்கம்"
print( வணக்கம்1 )
print( "String Length: ", வணக்கம்1.count )

for character in வணக்கம்1 {
	print( character )
}

//_________________________________________________________________

let exclamationMark: Character = "!"

let catCharacters: [Character] = ["C", "a", "t", "!", "🐱"]
let catString = String(catCharacters)
print(catString)
print( "String Length: ", catString.count )

for character in catString {
	print( character )	
}

//_________________________________________________________________

// Concatenating Strings and Characters
let string1 = "Hello"
let string2 = " there"
var welcome = string1 + string2
// Welcome now equals "hellow there"
print( welcome )

var instruction = "look over"
instruction += string2
print( instruction )

welcome.append(exclamationMark)
print( welcome )

//_________________________________________________________________

let wiseWords = "\"Imagination is more important than knowledge\" - Einstein"
print( wiseWords )

//Unicode Character “😊” (U+1F60A)
// Every Unicode Character Have Unicode Point
let smiley = "😊"
print( smiley )

let smileyAgain = "\u{1F60A}"
print( smileyAgain )

let dollarSign = "\u{24}"           // $,  Unicode scalar U+0024
let blackHeart = "\u{2665}"         // ♥,  Unicode scalar U+2665
let sparklingHeart = "\u{1F496}"    // 💖, Unicode scalar U+1F496

print( dollarSign )
print( blackHeart )
print( sparklingHeart )

//_________________________________________________________________

let eAcute: Character = "\u{E9}"                // é
let combinedEAcute: Character = "\u{65}\u{301}" // e followed by ́

print( eAcute )
print( combinedEAcute )

let precomposed: Character = "\u{D55C}"                 // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"  // ᄒ, ᅡ, ᆫ
print( precomposed )
print( decomposed )

let enclosedEAcute: Character = "\u{E9}\u{20DD}"
// enclosedEAcute is é⃝
print( enclosedEAcute )

let regionalIndicatorForUS: Character = "\u{1F1FA}\u{1F1F8}"
// regionalIndicatorForUS is 🇺🇸
print( regionalIndicatorForUS )

let regionalIndicatorForAUS: Character = "\u{1F1E6}\u{1F1FA}"
// regionalIndicatorForAUS is 🇦🇺
print( regionalIndicatorForAUS )

//_________________________________________________________________


var word = "cafe"
print("Word : \(word) Length: \(word.count)")
// prints "the number of characters in cafe is 4"

word += "\u{301}"
print("Word : \(word) Length: \(word.count)")

//_________________________________________________________________

// Comparing Strings
let quotation = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."

if quotation == sameQuotation {
    print("These two strings are considered equal")
}

//_________________________________________________________________

// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"
print( eAcuteQuestion )

// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}?"
print( combinedEAcuteQuestion )

let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"
print( combinedEAcuteQuestion2 )

if eAcuteQuestion == combinedEAcuteQuestion {
    print("These two strings are considered equal")
} else { print("Not Equal") }

if eAcuteQuestion == combinedEAcuteQuestion2 {
    print("These two strings are considered equal")
} else { print("Not Equal") }

//_________________________________________________________________

// Conversely, characters that are visually similar but do not have the 
// same linguistic meaning are not considered equal.
let latinCapitalLeterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

if latinCapitalLeterA != cyrillicCapitalLetterA {
    print("These two characters are not equivalent")
} else { print("Not Equal") }

print( latinCapitalLeterA )
print( cyrillicCapitalLetterA )

//_________________________________________________________________


// Prefix and Suffix Equality
let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
]
var act1SceneCount = 0
for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1") {
        act1SceneCount += 1
    }
}
print("There are \(act1SceneCount) scenes in Act 1")

var mansionCount = 0
var cellCount = 0
for scene in romeoAndJuliet {
    if scene.hasSuffix("Capulet's mansion") {
        mansionCount += 1
    } else if scene.hasSuffix("Friar Lawrence's cell") {
        cellCount += 1
    }
}
print("\(mansionCount) mansion scenes; \(cellCount) cell scenes")

//_________________________________________________________________

// Unicode Representations of Strings
let dogString = "Dog!!🐶"
print( "String: ", dogString, "Length : ", dogString.count )
// Printing Unicode Characters
for character in dogString {
	print( character, terminator :  " : " )
}

print()

let dogStringAgain = "Dog‼🐶"
print( "String: ", dogStringAgain, "Length : ", dogStringAgain.count )
// Printing Unicode Characters
for character in dogStringAgain {
	print( character, terminator :  " : " )
}


print()
// Printing Unicode Points For Unicode Characters
for unicodePoint in dogString.utf8 {
	print( unicodePoint, terminator: " : ")
}

print()
// Printing Unicode Points For Unicode Characters
for unicodePoint in dogStringAgain.utf8 {
	print( unicodePoint, terminator: " : ")
}

// ‼
// 0xE2 0x80 0xBC
// 🐶
// 0xF0 0x9F 0x90 0xB6

/*

print()
// Printing Unicode Points For Unicode Characters
for unicodePoint in dogString.utf16 {
	print( unicodePoint, terminator: " : ")
}

// print()
// for point in "🐶".utf8 {
// 	print( point, terminator: " : ")
// }

// print()
// for point in "🐶".utf16 {
// 	print( point, terminator: " : ")
// }

// print()
// for point in "🐶".unicodeScalars {
// 	print( point, terminator: " : ")
// }

*/

//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________
//_________________________________________________________________

// https://codeshare.io/5R7RWO
// https://codeshare.io/5R7RWO
// https://codeshare.io/5R7RWO

