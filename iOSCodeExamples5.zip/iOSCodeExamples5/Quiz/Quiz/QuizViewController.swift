//
//  ViewController.swift
//  Quiz
//
//  Created by Amarjit Singh on 29/05/24.
//

import UIKit

class QuizViewController: UIViewController {
    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var answerLabel: UILabel!
    
    let questions: [String] = [
        "What is 7+7?",
        "What is Capital of India?",
        "What is Chocolate made of?"
    ]
    
    let answers: [String] = [
        "14",
        "New Delhi",
        "Chocoa, Milk and Sugar"
    ]
    
    var currentQuestionIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        questionLabel.text = questions[ currentQuestionIndex ]
    }

    @IBAction func showNextQuestion(_ sender: UIButton) {
        print("Function: \(#function) Called...")
        currentQuestionIndex = currentQuestionIndex + 1
        if currentQuestionIndex == questions.count {
            currentQuestionIndex = 0
        }
        
        let question : String = questions[ currentQuestionIndex ]
        questionLabel.text = question
        answerLabel.text   = "???"
    }
    
    @IBAction func showAnswer( _ sender: UIButton ) {
        print("Function: \(#function) Called...")
        let answer: String = answers[ currentQuestionIndex ]
        answerLabel.text = answer
    }
}

