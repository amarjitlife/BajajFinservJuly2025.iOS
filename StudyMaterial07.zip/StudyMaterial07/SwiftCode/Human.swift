
//____________________________________________________________________________

// Creating A Type Superpower
protocol Superpower {
	func fly()
	func saveWorld()
}

// Making Spiderman Type Of Superpower
class Spiderman : Superpower {
	func fly() { print("Fly Like Spiderman!") }
	func saveWorld() { print("SaveWorld Like Spiderman!") }	
}

// Making Superman Type Of Superpower
class Superman : Superpower {
	func fly() { print("Fly Like Superman!") }
	func saveWorld() { print("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	func fly() { print("Fly Like Heman!") }
	func saveWorld() { print("SaveWorld Like Heman!") }	
}

class Wonderwoman :  Superpower {
	func fly() { print("Fly Like Wonderwoman!") }
	func saveWorld() { print("SaveWorld Like Wonderwoman!") }	
}

class HanumanJi : Superpower {
	func fly() { print("Fly Like HanumanJi!") }
	func saveWorld() { print("SaveWorld Like HanumanJi!") }	
}

// Inheritance Design
// class Human : Spiderman {
// class Human : Superman {	
// class Human : Heman {
class Human : Wonderwoman {
	override func fly() 		{ super.fly() 		}
	override func saveWorld() 	{ super.saveWorld() }	
}


func playWithHuman() {
	let s = Spiderman()
	s.fly()
	s.saveWorld()

	let h = Human()
	h.fly()
	h.saveWorld() 
}

playWithHuman()

//____________________________________________________________________________

// Composition Is Alternative To Inheritance
// Composition Design 
// class Human : Spiderman {
// class Human : Superman {	
// class Human : Heman {
class HumanBetter {
	// let power = Spiderman()
	// let power = Superman()
	// let power = Heman()
	let power = Wonderwoman()
	func fly() 		{ power.fly() 		}
	func saveWorld() 	{ power.saveWorld() }	
}

func playWithHumanBetter() {
	let s = Spiderman()
	s.fly()
	s.saveWorld()

	let h = HumanBetter()
	h.fly()
	h.saveWorld() 
}

print("\nHuman Better...")
playWithHumanBetter()


//____________________________________________________________________________

// DESIGN PRINCPLES
//		Design Towards Abstract Types Rather Than Concrete Types

// DESIGN PRACTICES
//		Desing Towards Interfaces/Protocols Rather Than Concrete Classes/Structure etc.
//		Always Prefer Composition Over Inheritance

// Composition Is Better Than Inheritance
// HumanBest Is Polymorphics
class HumanBest { // Human Is Delegator
	// power Is As Delegate
	var power: Superpower? = nil
	func fly() 			{ power?.fly() 		}
	func saveWorld() 	{ power?.saveWorld() }	
}

func playWithHumanBest() {
	let s = Spiderman()
	s.fly()
	s.saveWorld()

	let h = HumanBest()
	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()	 

	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()	 

	h.power = HanumanJi()
	h.fly()
	h.saveWorld()	 
}

print("\nHuman Best...")
playWithHumanBest()


//____________________________________________________________________________

// Delegation Design Pattern

/*
protocol DiceGame {
    var dice: Dice { get }
    func play()
}

protocol DiceGameDelegate {
    func gameDidStart(game: DiceGame)
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int)
    func gameDidEnd(game: DiceGame)
}

class SnakesAndLadders: DiceGame {
    let finalSquare = 25
    let dice = Dice(sides: 6, generator:LinearCongruentialGenerator())
    var square = 0
    var board: [Int]
    init() {
        board = [Int](count: finalSquare + 1, repeatedValue: 0)
        board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
        board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08
    }
    
    var delegate: DiceGameDelegate?

    func play() {
        square = 0
        delegate?.gameDidStart(self)
        gameLoop: while square != finalSquare {
            let diceRoll = dice.roll()
            delegate?.game(self, didStartNewTurnWithDiceRoll: diceRoll)
            switch square + diceRoll {
            case finalSquare:
                break gameLoop
            case let newSquare where newSquare > finalSquare:
                continue gameLoop
            default:
                square += diceRoll
                square += board[square]
            }
        }
        delegate?.gameDidEnd(self)
    }
}

class DiceGameTracker: DiceGameDelegate {
    var numberOfTurns = 0
    func gameDidStart(game: DiceGame) {
        numberOfTurns = 0
        if game is SnakesAndLadders {
            print("Started a new game of Snakes and Ladders")
        }
        print("The game is using a \(game.dice.sides)-sided dice")
    }
    func game(game: DiceGame, didStartNewTurnWithDiceRoll diceRoll: Int) {
        ++numberOfTurns
        print("Rolled a \(diceRoll)")
    }
    func gameDidEnd(game: DiceGame) {
        print("The game lasted for \(numberOfTurns) turns")
    }
}
let tracker = DiceGameTracker()
let game = SnakesAndLadders()
game.delegate = tracker
game.play()

*/

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________


// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/


