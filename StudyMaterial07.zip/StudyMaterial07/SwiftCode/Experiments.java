
package learnJava;

import java.util.Arrays;


public class Experiments {
	public static void playWithNullables() {
		String greeting = new String("Hello World!");
		greeting = null;
		System.out.println( greeting );

		// String greetingUpper = greeting.toUpperCase();
		String greetingUpper;
		// if ( greeting != null ) 
		greetingUpper = greeting.toUpperCase();
		// Exception in thread "main" java.lang.NullPointerException: 
		System.out.println( greetingUpper );
	}

	public static void playWithEqality() {
		String greeting = new String("Hello");
		String hello = new String("Hello");

		if ( greeting == hello ) {
			System.out.println( "Hello World" );
		} else {
			System.out.println( "It's Not My World" );
		}
	}


	public static void playWithArrays() {
		String[] names = new String[5];
		for( int i = 0 ; i < names.length ; i++ ) { 
			names[i] = "Thakur"; 
		}	
		String[] something = names;

		System.out.println("Names : " + Arrays.toString( names ) );
		System.out.println("Names : " + Arrays.toString( something ) );

		names[0] = "Gabbar";

		System.out.println("Names : " + Arrays.toString( names ) );
		System.out.println("Names : " + Arrays.toString( something ) );
	}



	public static void main( String[] args ) {
		// System.out.println("\n\nFunction: playWithNullables");
		// playWithNullables();

		System.out.println("\n\nFunction: playWithEqality");
		playWithEqality();

		System.out.println("\n\nFunction: playWithArrays");
		playWithArrays();


		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");
		// System.out.println("\n\nFunction: ");

	}
}
