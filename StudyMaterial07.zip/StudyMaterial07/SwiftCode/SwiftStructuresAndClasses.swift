
//____________________________________________________________________________

// Value Type
struct Resolution {
    var width 	= 0 // Initialised With Default Values
    var height 	= 0
}

// let someResolution = Resolution()
// `- note: change 'let' to 'var' to make it mutable
var someResolution = Resolution()

print( someResolution )
print( someResolution.width )
print( someResolution.height )

someResolution.width 	= 766
someResolution.height 	= 500
print( someResolution.width )
print( someResolution.height )

// print("The width of someResolution is \(someResolution.width)")

//____________________________________________________________________________

var vga = Resolution( width: 640, height: 480 )
let somevga = vga // Value Assignment

print( vga )
print( somevga )

vga.width = 999

print( vga )
print( somevga )

//____________________________________________________________________________

// Reference Type
class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String = "Uknown"
}

let someVideoMode = VideoMode()

let someVideoModeAgain = someVideoMode // Reference Assignment
print( someVideoMode.name, someVideoMode.resolution )
print( someVideoModeAgain.name, someVideoModeAgain.resolution )

someVideoMode.name = "Default Resolution"
someVideoMode.resolution = vga

// print( someVideoMode.name = "DOmething", someVideoMode.resolution )
print( someVideoMode.name, someVideoMode.resolution )
print( someVideoModeAgain.name, someVideoModeAgain.resolution )

//____________________________________________________________________________

// Value Type
enum CompassPoint {
    case North, South, East, West
}

var currentDirection = CompassPoint.West
let rememberedDirection = currentDirection // Value Assignment

print( currentDirection )
print( rememberedDirection )

currentDirection = .North

print( currentDirection )
print( rememberedDirection )

//____________________________________________________________________________

let hd = Resolution(width: 1920, height: 1080)

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0
print("The frameRate property of tenEighty is now \(tenEighty.frameRate)")

// Identity Operators
if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/
// https://codebunk.com/b/7221100718298/

