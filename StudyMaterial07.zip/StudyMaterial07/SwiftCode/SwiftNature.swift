
//____________________________________________________________________________
// MUTABLE STATE

// Type Inferencing and Binding Decision
// 		In Swift/C/C++/Java It's Compile Time Hence These Are Static Langauge
// 		In Python/JavaScript It's Run Time Hence These Are Dynamic Langauge

// 	1. Type Inferencing From RHS Value
//	2. Type Binding To LHS ( Inferred Type )

var someString = "Hello World!"
print( someString )

someString = "Hello World! Welcome!!!"
print( someString )

// IMMUTABLE STATE
let someString1 = "Hello World!"
print( someString1 )

// someString1 = "Hello World! Welcome!!!"
// // error: cannot assign to value: 'someString1' is a 'let' constant
// print( someString1 )

// Explicitly Annotated The Type
let someString2: String = "Hello World!"
print( someString2 )

// let someString3 // error: type annotation missing in pattern
// print( someString3 )

//____________________________________________________________________________
// EXPERIMENT FOLLOWING IN YOUR FAVORITE LANGUAGE?

// DESIGN PRINCIPLE
//		Objects/Variables Must Be Initialised To Valid Values

// let someString3: String
// print( someString3 )

// let something: Int
// print( something )

 // error: constant 'something' used before being initialized
// error: constant 'someString3' used before being initialized

//____________________________________________________________________________

let something1 = 90

// Following Both Lines Are Equivalent
let something2 = 90.90 // By Default: Inferred Type Will Be Double
let something3: Double = 90.90 // By Default: Inferred Type Will Be Double

// Making Explictly Float
let something4: Float = 90.90 // By Default: Inferred Type Will Be Double

print( something1 )
print( something2 )
print( something3 )
print( something4 )

//____________________________________________________________________________

let days = 4
let label = " Day!"

// let someString3 = days + label
// error: binary operator '+' cannot be applied to operands of type 'Int' and 'String'
//					Explicitly Type Casting To String
let someString3 = String( days )  + label
print( someString3 )

//____________________________________________________________________________

let apples = 5
let oragnes = 3
let prices = 90.90

// String Interpolation
let appleSummary = "I Have \(apples) Apples"
let oragnesAndAppleSummary = "I Have \(apples) Apples and \(oragnes) Oranges with \(prices) Price"

print(appleSummary)
print( oragnesAndAppleSummary )

//____________________________________________________________________________

// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN TOWARDS MUTABILITY
// i.e.
//		Things Which Are Not Supposed To Be Changed Must Be Immutable By Design

//____________________________________________________________________________


// Following Both Lines Are Equivalent
let shoppingList = ["Coffee", "Chocolates", "Milk", "Bread", "Eggs" ]
let shoppingList1 : [String] = ["Coffee", "Chocolates", "Milk", "Bread", "Eggs" ]

print( shoppingList )
print( shoppingList1 )

print( shoppingList[0] )
print( shoppingList[1] )

// Empty Array Of String
// let shoppingList2 = [] // Compilation Error
let shoppingList2 : [String] = [] // Literal Syntax
print( shoppingList2 )

// Empty Array Of String
let shoppingList3 = [String]() // Constructor Call
print( shoppingList3 )

// 1. Inferred Type From RHS Is [Int]
// 2. Binded Type To LHS Is [Int] Hence Type Of scores Is [Int]
let scores = [100, 90, 88, 77, 20, 99, 10, 30 ]
let scores1 : [Int] = [100, 90, 88, 77, 20, 99, 10, 30 ]

for score in scores {
	if score > 33 { print( "Passed" ) }
	else { print( "Failed" ) }
}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

