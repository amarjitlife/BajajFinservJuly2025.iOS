//____________________________________________________________________________

let maximumNumberOfLogins = 10
var currentLoginAttemp = 0

var x = 0.0, y = 0.0, z = 1.0
print( x, y, z )
print( x, y, z, separator: " ## ", terminator : " <<< \n" )

let welcomeMessage: String 
// This Initialisation Must Happen Before First Usage
welcomeMessage = "Welcome To Swift!"

//	In C/C++: String Are ASCII Strings
//	In Swift: String Are Unicode Strings

let नमस्ते = "नमस्ते namaskāram"
print( नमस्ते )

let 안녕하세요 = "안녕하세요 Hello In Korean!"
print( 안녕하세요 )

let 🐶🐮 = "dogcow"
print( 🐶🐮 )

let dogcow = "🐶🐮"
print( dogcow )

let வணக்கம் = "Vanakam : வணக்கம்"
print ( வணக்கம் )

let someString4 = "Good Afternoon!" ; print( someString4 )

//____________________________________________________________________________

let minValue = Int.min
let maxValue = Int.max
print( minValue, maxValue )

let minValue1 = Int8.min // Signed Int Of 8 Bit
let maxValue1 = Int8.max
print( minValue1, maxValue1 )

let minValue2 = UInt8.min // Unsigned Int Of 8 Bit
let maxValue2 = UInt8.max
print( minValue2, maxValue2 )

let minValue3 = Int16.min // Signed Int Of 8 Bit
let maxValue3 = Int16.max
print( minValue3, maxValue3 )

let minValue4 = UInt16.min // Unsigned Int Of 8 Bit
let maxValue4 = UInt16.max
print( minValue4, maxValue4 )


//____________________________________________________________________________

// All Following Are Of Type Int
// 		Note: Data Represenation Is Not Part Of Data Type
let someNumber1 = 17 // Base 10
let someNumber2 = 0b10001 // Base 2
let someNumber3 = 0o21 // Base 8
let someNumber4 = 0x11 // Base 16

print( someNumber1 )
print( someNumber2 )
print( someNumber3 )
print( someNumber4 )

let oneMillion = 1_000_000
print( oneMillion )

//____________________________________________________________________________
// For Following Code

// In C/C++/Java
//		Implicit Type Conversion Happens 

// In Swift Language Is Strictly Typed Language
//		Most Of The Places Implicit Type Conversion Not Allowed

let twoThousand: UInt16 = 2_000
let one: UInt8 = 1

// let twoThousandAndOne = twoThousand + one 
// error: binary operator '+' cannot be applied to operands of type 'UInt16' and 'UInt8'
let twoThousandAndOne = twoThousand + UInt16( one ) 
print( twoThousandAndOne )


let maxValueUInt16: UInt16 = 65535
// let maxValueAndOne = maxValueUInt16 + UInt16( one ) // Here + Overflow/Underflow Aware
// print( maxValueAndOne ) 

let maxValueAndOne1 = maxValueUInt16 &+ UInt16( one ) // Here + Similar To C/C++ Behaviour
print( maxValueAndOne1 ) 

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// HOME WORK     HOME WORK 		HOME WORK 		HOME WORK 		HOME WORK
//
// WRITE ABOVE CODE IN JAVA, PYTHON AND SEE WHAT BEHAVIOUR WILL BE
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//____________________________________________________________________________

let integerFourPointSeven = Int( 4.75 )
print( integerFourPointSeven )

//____________________________________________________________________________

let three = 3
let fraction = 0.14159

// let pi = three + fraction
let pi = Double( three )  + fraction
print( pi )

let piAgain = 3 + 0.14159 // Constant Folding In Action
print( piAgain )

//____________________________________________________________________________

let orangesAreOrange = true
let turnipsAreDeliciout = false

if turnipsAreDeliciout {
	print( "Tasty Stuff..." )
} else {
	print( "Not Tasty Stuff..." )	
}

//____________________________________________________________________________

let i = -10

if i == -10 {
	print("Value: \(i)")
} else {
	print("Something Else ...")
}

// if i {
// 		print("Value: \(i)")
// } else {
// 		print("Something Else ...")
// }

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// HOME WORK     HOME WORK 		HOME WORK 		HOME WORK 		HOME WORK
//
// WRITE ABOVE CODE IN JAVA, PYTHON AND SEE WHAT BEHAVIOUR WILL BE
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//____________________________________________________________________________

// let http404Error: (Int, Int) = ( 404, "Not Found" ) // Tuple Of 2 Value
// error: cannot convert value of type '(Int, String)' to specified type '(Int, Int)'

let http404Error0: (Int, String) = ( 404, "Not Found" ) // Tuple Of 2 Value
let http404Error1 = ( 404, "Not Found" ) // Tuple Of 2 Value
let ( statusCode, statusMessage ) = http404Error0 // Tuple Unpacking
print("Status : \(statusCode) Message: \(statusMessage)")

print( http404Error0 )
print( http404Error1 )

let ( status, _ ) = http404Error0 // Tuple Unpacking
print( status )

//____________________________________________________________________________

let possibleNumber = "12345"
// let possibleNumber = "12345ABCMJ"

let convertedNumber = Int( possibleNumber )
// print( convertedNumber )  // Optional(12345)

// Unwrapping Optional Value
// 		If Optional Value Is nil Than Code Will Crash
// BAD CODE
print( convertedNumber! )  // Optional(12345)

// GOOD CODE
// 		Optional Values Must Be Checked For nil Before Unwrapping
if convertedNumber != nil { 
	print( convertedNumber! )
} else {
	print("Nothingness Found: Number Conversion Failed")
}

//____________________________________________________________________________

// BETTER CODE
// Idioms Swift Style
// Following Code Is Equivalent To Above Code
if let convertedNumber = Int( possibleNumber ) {
	print( convertedNumber ) // // convertedNumber Is Local To if Block
} else {
	print("Nothingness Found: Number Conversion Failed")	
}

// For Above if let Idiom Compiler Will Generate Following Code
let temporaryNumber = Int( possibleNumber )
if temporaryNumber != nil {
	let convertedNumber = temporaryNumber! // convertedNumber Is Local To if Block
	print( convertedNumber )
} else {
	print("Nothingness Found: Number Conversion Failed")		
}


if let firstNumber = Int( "44" ), let secondNumber = Int("99"), firstNumber < secondNumber  {
	print("\(firstNumber) Is Less Than \(secondNumber)")
} else {
	print("Something Else Happened...")
}

if let firstNumber = Int("4"), let secondNumber = Int("42"), firstNumber < secondNumber && secondNumber < 100 {
    print("\(firstNumber) < \(secondNumber) < 100")
} else {
	print("Something Else Happened...")
}


if let firstNumber = Int("4") {
    if let secondNumber = Int("42") {
        if firstNumber < secondNumber && secondNumber < 100 {
            print("\(firstNumber) < \(secondNumber) < 100")
        }
    }
}


// Cyclomatic Complexity
//		Reduce Cylomatic Complexity

// DESIGN PRACTICE
//		Write Code For Reading Rather Writing
//		Always Prefer Flater Coding Style Rather Nested Coding Style

//____________________________________________________________________________
// In Swift: By Default Types Are Non Nullable
//		Hence You Can't Store nil 
//		e.g. Int, String, Float, Double and so on

// In Java/C++: By Default Types Are Nullable
//		Hence You Can Store null 
//		Always Handle null Before Any Member Access

var number: Int = 99
print( number )

// number = nil //error: 'nil' cannot be assigned to type 'Int'
// print( number )

var greeting: String = "Good Morning!"
print( greeting )

// greeting = nil // error: 'nil' cannot be assigned to type 'String
// print( greeting )

// In Swift: To Make Nullable Types Append ? After Type
//		These Are Called Optional Types In Swift
//		Hence You Can Store nil 
//		e.g. Int?, String?, Float?, Double? and so on

var number1: Int? = 99
print( number1 )

number1 = nil //error: 'nil' cannot be assigned to type 'Int'
print( number1 )

var greeting1: String? = "Good Morning!"
print( greeting1 )

greeting1 = nil // error: 'nil' cannot be assigned to type 'String
print( greeting1 )

// Optional(99)
// nil
// Optional("Good Morning!")
// nil

// DESIGN PRINCIPLE
//		Design Towards Non Nullable Types Rather Than Nullable Types

//____________________________________________________________________________

let a: Int? = 44
let b: Int? = nil
// let b: Int? = 55
let c: Int? = 99

if let A = a, let B = b, let C = c {
	print(A, B, C)
} else {
	print("Nothingness Found")
}

//____________________________________________________________________________
// Can Use Equality Operator To Compare Strings

let name = "world"
if name == "world" {
	print("Hello World!")
} else {
	print("It's Not My World!")
}

print( "Alice" < "Bob" )
print( "Shahkrukh" < "Bob" )

// Can Use Equality Operator To Compare Tuples Also
let someTuple1 = (1, "Zebra") // Associated Values
let someTuple2 = (2, "Zebra")
let someTuple3 = (1, "Lion")

print( someTuple1 < someTuple2 )
print( someTuple1 < someTuple3 )

//____________________________________________________________________________

let contentHeight = 50
let hasHeader = false

let choice = ( hasHeader ) ? 50 : 20 // Terniary Operator

let choice1: Int 
if hasHeader {
	choice1 = 50 
} else {
	choice1 = 20
}

let choiceValue = contentHeight + choice
print( choiceValue )

//____________________________________________________________________________

let shoppingList = ["Coffee", "Chocolates", "Milk", "Bread", "Eggs", "Apple Watch", "Icecream" ]

for item in shoppingList {
	print( item )
}

let count = shoppingList.count
for index in 0..<count {
	print( shoppingList[index] )
}

for item in shoppingList[2...] {
	print( item )
}

for item in shoppingList[...2] {
	print( item )
}

for item in shoppingList[...4] {
	print( item )
}

for item in shoppingList[2...5] {
	print( item )
}

let range = 1...10
for i in range {
	print( i )
}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

