
//____________________________________________________________________________

var someInts = [Int]()
print("someInts is of type [Int] with \(someInts.count) items.")
print( someInts.isEmpty )

var threeDoubles = [Double]( repeating: 0.0, count: 3)
print( threeDoubles )

var threeDoublesAgain = [Double]( repeating: 9.9, count: 3)
print( threeDoublesAgain )

let sixDoubles = threeDoubles + threeDoublesAgain
print( sixDoubles )


//____________________________________________________________________________

// Creating an Array with an Array Literal
var shoppingList: [String] = ["Eggs","Milk"]
print( shoppingList )

// Accessing and Modifying an Array
print("The shopping list contains \(shoppingList.count) items.")

if shoppingList.isEmpty {
    print("The shopping list is empty.")
} else {
    print("The shopping list is not empty")
}

shoppingList.append("Flour")
shoppingList += ["Baking Powder"]
print( shoppingList )

shoppingList += ["Chocolate Spread", "Cheese", "Butter"]
print( shoppingList )

var firstItem = shoppingList[0]
shoppingList[0] = "Six eggs"

shoppingList[4...6] = ["Bananas", "Apples"]
print( shoppingList )

shoppingList.insert("Maple Syrup", at: 0)
print( shoppingList )

let mapleSyrup = shoppingList.remove(at: 0)
print( mapleSyrup )

firstItem = shoppingList[0]
print( firstItem )

let apples = shoppingList.removeLast()
print( apples )


for item in shoppingList {
	print( item )
}

for item in shoppingList.enumerated() {
	print( item )
}

for ( index, value ) in shoppingList.enumerated() {
	print( index, value )
}

//____________________________________________________________________________

var letters = Set<Character>()
print( letters )
print( letters.isEmpty )


letters.insert( "X" )
letters.insert( "D" )
letters.insert( "A" )
letters.insert( "B" )
letters.insert( "A" )

print( letters )

for letter in letters {
	print( letter )
}

print( letters.sorted() )
print( letters.sorted().reversed() )

//____________________________________________________________________________


let oddDigits: Set = [1,3,5,7,9]
let evenDigits: Set = [0,2,4,6,8]
let singleDigitPrimeNumbers: Set = [2,3,5,7]

var result = oddDigits.union(evenDigits).sorted()
print( result )

result = oddDigits.intersection(evenDigits).sorted()
print( result )

result = oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
print( result )

result = oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()
print( result )

//____________________________________________________________________________

// Dictionaries
let alongFormDict = Dictionary<String, Int>()
let shortFormDict = [String:Int]()

// Creating an Empty Dictionary
var namesOfIntegers = [Int: String]()
print( namesOfIntegers )

namesOfIntegers[16] = "sixteen"
print( namesOfIntegers )

namesOfIntegers = [:]
print( namesOfIntegers )

// Creating a Dictionary with a Dictionary Literal
var airports0: Dictionary<String, String> = ["TYO":"Tokyo", "DUB":"Dublin"]

var airports: [String: String] = ["YYZ":"Toronto Pearson", "DUB":"Dublin"]
print( airports0 )
print( airports )

// Accessing and Modifying a Dictionary
if airports.isEmpty {
    print("The airports dictionary is empty.")
} else {
    print("The airports dictionary is not empty.")
}

airports["LHR"] = "London"
airports["LHR"] = "London Heathrow"
print( airports )

if let oldValue = airports.updateValue("Dublin International", forKey: "DUB") {
    print("The old value for DUB was \(oldValue).")
}

if let airportName = airports["DUB"] {
    print("The name of the airport is \(airportName)")
} else {
    print("That airport is not in the airports dictionary.")
}


airports["APL"] = "Apple International"
print( airports )

airports["APL"] = nil
print( airports )

if let removedValue = airports.removeValue(forKey: "DUB") {
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary does not contain a value for DUB.")
}


for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
}

for airportName in airports.values {
    print("Airport name: \(airportName)")
}

let airportCodes = [String](airports.keys)
let airportNames = [String](airports.values)


//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

