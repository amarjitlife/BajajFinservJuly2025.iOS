
//____________________________________________________________________________
// INHERITANCE 

class Vehicle {
	var numberOfWheels: Int
	var maxPassengers: Int 

	init() {
		numberOfWheels	= 0
		maxPassengers 	= 1 
	}

	func description() -> String {
		return "Number Of Wheels: \(numberOfWheels) \nMax Passengers: \(maxPassengers)"
	}
}

let someVehicle = Vehicle()
print( "Vehicle:\n", someVehicle.description() )

// Inheriting From Parent Class Vehicle
class Bicycle : Vehicle {
	override init() {
		// Calling Parent Class Constructor/Initialiser 
		//		To Initialise Properties Coming From Parent Class
		super.init() 		
		numberOfWheels = 2  // Configuring Some Properties As Per Child Classs
	}
}

let biycle = Bicycle()
print("Bicyle:\n", biycle.description() )

class Tandem: Bicycle {
    override init() {
        super.init()
        maxPassengers = 2
    }
}
let tandem = Tandem()
print("Tandem: \(tandem.description())")


//____________________________________________________________________________

// Design Practice
// 		Object Must Be Legal Object With Valid States

// All Properties Must Initialised
//		At least with Either Default Values Or At Initialser
class Car: Vehicle {
	var speed: Double = 0.0 // Can Initialise Properties With Default Values
	// var speed: Double = 100.0 // Can Initialise Properties With Default Values
	// var speed: Double // Can Initialise Properties With Default Values

	override init() {
		super.init()
		maxPassengers 	= 5
		numberOfWheels 	= 4
		// speed = 10.10
	}
	// Overiding Member Function From Parent Class
	override func description() -> String {
		return super.description() + "; " + "Travelling At \(speed) Km/Hour"
	}
}

let car = Car()
print("Car: ", car.description() )

//____________________________________________________________________________

class SpeedLimitedCar: Car {
	// var speed: Double // error: cannot override with a stored property 'speed'	
	override var speed: Double { // Override Getter/Setter For Parent Class
		get { 
			return super.speed 
		}
		set {
			print("speed : Setter Called")
			let maxSpeed: Double = 99.99
			super.speed = min( newValue, maxSpeed ) 
		}
	}

	override init() {
		super.init()
		maxPassengers 	= 5
		numberOfWheels 	= 4
		// let maxSpeed: Double = 99.99
		// if ( speed > maxSpeed ) { speed = maxSpeed // setSpeed( maxSpeed )}
	}	
}

let limitedCar = SpeedLimitedCar()

print( limitedCar.speed )
limitedCar.speed = 80.80
print( limitedCar.speed )

limitedCar.speed = 200.00
print( limitedCar.speed )


//____________________________________________________________________________

class AutomaticCar: Car {
	var gear = 1
	override var speed: Double {
		didSet { //Using Property Observer To Set Conditons
			gear = Int( speed / 10.0 ) + 1
		}
	}

	override func description() -> String {
		return super.description() + " In Gear : \(gear)"
	}
}


let automaticCar = AutomaticCar()
automaticCar.speed = 35.0
print("Automatic Car: ", automaticCar.description() )

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/
// https://codebunk.com/b/4461100718427/

