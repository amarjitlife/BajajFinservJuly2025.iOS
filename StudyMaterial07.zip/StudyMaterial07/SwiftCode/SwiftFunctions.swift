
//____________________________________________________________________________
// Function Taking 0 Argument
//		Returning String Type Value

func sayHelloWorld() -> String { 
	return "Hello World!" 
}
print( sayHelloWorld())

// Function Taking 1 Argument Of Type String
//		Returning String Type Value
func sayHello( personName: String ) -> String {
	let greeting = "Hello, " + personName + "!"
	return greeting
}
//				Named Arguments
print( sayHello( personName: "Gabbar Singh") )
print( sayHello( personName: "Mokambo") )
// print( sayHello( "Ram Singh") ) //  `- error: missing argument label 'personName:' in call
print( sayHello( personName: "Ram Singh") )

func sayHelloAgain( personName: String ) -> String {
	return "Hello, " + personName + "!"
}
//				Named Arguments
print( sayHelloAgain( personName: "Gabbar Singh") )
print( sayHelloAgain( personName: "Mokambo") )

//____________________________________________________________________________
// Function Taking 2 Arguments Of Type Int
//		Returning Int Type Value
func halfOpenRangeLength( start: Int, end: Int ) -> Int {
	return end - start
}

print( halfOpenRangeLength( start: 1, end: 10 ) )

//____________________________________________________________________________
// Function With Multiple Return Values

func minMax( numbers : [Int] ) -> (min: Int, max: Int) {
	var currentMin: Int = numbers[0]
	var currentMax: Int = numbers[0]

	for value in numbers[1..<numbers.count] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

let bounds = minMax( numbers: [10, 20, -10, 99, 88, 60, 20, 30, -99] )
print( bounds )
print( bounds.min, bounds.max )


//____________________________________________________________________________

// Function Parameter/Argument Can Have Two Names
//		1 For External World
//		1 For Local Use Within Function

func someFunction( externalParameterName localParameterName: Int ) -> Int {
	let some = localParameterName
	return some
}

print( someFunction( externalParameterName: 999) )
print( someFunction( externalParameterName: 111) )

// Assume Following Function Comes From Some 3rd Party Library 
func join( s1: String, s2: String, joiner: String ) -> String {
	return s1 + joiner + s2
}

// Creating New API i.e. Wrapper Function With Project Coding Style
func join( string s1: String, toString s2: String, withJoiner joiner: String ) -> String {
	return join( s1: s1, s2: s2, joiner: joiner)
}

// Using New Wrapper API
print( join( string: "Hello", toString: "World", withJoiner: " " ) )

//____________________________________________________________________________

// Polymorphic Function
//																Default Parameter
func joinAgain( string s1: String, toString s2: String, withJoiner joiner: String = " ") -> String {
	return join( s1: s1, s2: s2, joiner: joiner)
}

// Using New Wrapper API
print( joinAgain( string: "Hello", toString: "World", withJoiner: ", " ) )
print( joinAgain( string: "Hello", toString: "World" ) )

//____________________________________________________________________________

// Polymoprhic Function
// Variadiac Function
//		Function Taking Variable Number of Arguments
func arithematicMean( numbers: Double... ) -> Double {
	var total : Double = 0.0
	for number in numbers {
		total += number
	}
	return total / Double( numbers.count )
}


print( arithematicMean( numbers: 1, 2, 3 ) )
print( arithematicMean( numbers: 1, 2, 3, 4, 5, 6))
print( arithematicMean( numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10))


//____________________________________________________________________________
// DESIGN PRINCIPLE
//		DEsigned Towards Immutability Rather Than Mutability

// Function Parameters Are Constant By Default
func doChanges( number: Int ) -> Int {
	// number = number + 99
	//		error: cannot assign to value: 'number' is a 'let' constant
	var number = number + 99
	// 		Redefining New Variable With Same Name As Parameter
	//			This Will Shadow Parameter Name
	number = number + 1
	return number
}

print( doChanges( number: 100 ) )

//____________________________________________________________________________

// Constant Parameters and Variable 
func alignRight( string: String, totalLength: Int, pad: Character) -> String {
    var stringResult: String = ""
    let amountToPad = totalLength - string.count
    if amountToPad < 1 {
        return string
    }
    let padString = String(pad)
    for _ in 1...amountToPad {
        stringResult = stringResult + padString 
    }
    stringResult = stringResult + string
    return stringResult
}

let originalString = "hello"
let paddedString = alignRight(string: originalString, totalLength: 20, pad: "-")
print( paddedString )


//____________________________________________________________________________

func swapInts( a: Int, b: Int ) {
	var aa = a
	var bb = b
	var temp : Int
	temp = aa
	aa = bb
	bb = temp
}

func swapIntsAgain( a: Int, b: Int ) {
	var a = a
	var b = b
	var temp : Int
	temp = a
	a = b
	b = temp
}

func swapValues( a: inout Int, b: inout Int ) {
	var temp : Int
	temp = a
	a = b
	b = temp
}

func playWithSwapping() {
	var aa = 100
	var bb = 200

	print( aa, bb )
	swapInts( a: aa, b: bb )
	print( aa, bb )	

	swapIntsAgain( a: aa, b: bb )
	print( aa, bb )	

	// Pass By Reference
	swapValues( a: &aa, b: &bb ) // Passing Reference
	print( aa, bb )	
}

playWithSwapping()

//____________________________________________________________________________
// Function Type
//		(Int, Int) -> Int

// sum And sub Are Object of Function Type (Int, Int) -> Int
func sum( x: Int, y: Int) -> Int { return x + y }
func sub( x: Int, y: Int) -> Int { return x - y }
func sum3( x: Int, y: Int, z: Int) -> Int { return x + y + z }

// Higher Order Function
//		Function Which Takes And/Or Return Functions

// Function Type
//		(Int, Int (Int, Int) -> Int) -> Int
func calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( x, y )
}

// Polymorphic Function
func playWithCalculator() {
	let a = 200
	let b = 100
	var result: Int

	result = calculator( x: a, y: b, operation: sum )
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: sub )
	print("Result : ", result )

	var something: (Int, Int) -> Int = sum
	result = something( 11, 22 )
	print("Result : ", result )

	// something = sum3

	let somethingAgain:(Int, Int, (Int, Int) -> Int) -> Int = calculator

	let sumLambda = { (x: Int, y: Int) -> Int in return x + y }
	let subLambda = { (x: Int, y: Int) -> Int in return x + y }

	result = calculator( x: a, y: b, operation: sumLambda )
	print("Result : ", result )

	result = calculator( x: a, y: b, operation: subLambda )
	print("Result : ", result )

	result = calculator( x: a, y: b, operation:  { (x, y) in return x * y } )
	print("Result : ", result )
}

playWithCalculator()

//____________________________________________________________________________

func stepForward( input: Int ) -> Int { return input + 1 }
func stepBackward( input: Int ) -> Int { return input - 1 }

func chooseStep( backwards: Bool ) -> (Int) -> Int {
	return backwards ? stepBackward : stepForward
}

func playWithChooseSteps() {
	let something: (Int) -> Int  = stepForward
	let somethingAgain: (Bool) -> (Int) -> Int = chooseStep
}


//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

