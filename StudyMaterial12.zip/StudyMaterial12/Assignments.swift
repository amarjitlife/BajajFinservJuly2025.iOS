//____________________________________________________________________________
//
// DAY 01
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT
		Read Types an Expression Chapter
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 02
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Chapter : Pointers and Arrays
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 03
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: READING ASSINGMENT [ MUST MUST MUST ]
		Chapter : Pointers and Arrays
		The C Programming Language, 2nd Edition
			By Brian Kerngiham and Dennis Ritchie

ASSIGNMENT A3: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 04
//____________________________________________________________________________


ASSIGNMENT A1: REVISE AND PRACTICE SWIFT CODE DONE CLASS

ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS

//____________________________________________________________________________
//
// DAY 05
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE CODE EXAMPLES DONE IN CLASS
ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS
ASSIGNMENT A3: READING APPLE DOCUMENTATIONS
	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#equals-java.lang.Object-
	https://developer.apple.com/documentation/swift/string
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/		
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/deinitialization/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/optionalchaining/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/errorhandling/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/typecasting/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/nestedtypes/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/


//____________________________________________________________________________
//
// DAY 06
//____________________________________________________________________________

ASSIGNMENT A1: REVISE AND PRACTICE CODE EXAMPLES DONE IN CLASS
ASSIGNMENT A2: COMPLETE ALL EXPERIMENTATION ASSIGNMENTS
ASSIGNMENT A3: READING APPLE DOCUMENTATIONS
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/accesscontrol/#Guiding-Principle-of-Access-Levels
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/advancedoperators/
	
	iOS Apple Guide Reading Assignment
		Read Following Sections From Apple iPhone App Programming Guide

			App Design Basics 13
				Doing Your Initial Design 13
				Learning the Fundamental iOS Design Patterns and Techniques 14 
				Translating Your Initial Design into an Action Plan 14
				Starting the App Creation Process 15
				Best Practices for Maintaining User Privacy 18

			Core App Objects 21
				The Core Objects of Your App 21 
				The Data Model 24

			App States and Multitasking 37 
				Managing App State Changes 38
				The App Launch Cycle 40 
				Responding to Interruptions 47 
				Moving to the Background 49 
				Returning to the Foreground 53 
				App Termination 56
				The Main Run Loop 57

ASSIGNMENT A4: REFACTOR FOLLOWING CODE
	1. Incorporate Good Swift Design Practices
	2. Organise Code Better Way
	3. Apply DRY [ Don't Repeat Yourself ]

	     └── iOSCodeSwift
	         └── ApplicationLifeCycle
	             └── ApplicationLifeCycle3


//____________________________________________________________________________
//
// DAY 07
//____________________________________________________________________________


ASSIGNMENT A1: iOS Code Exploration and Reasoning Assignment
	Explore Following Code, Try To Reason The Code

		├── StudyMateria9.1
		 	└── iOSCodeExamples2
		     └── iOSCodeSwift
		         └── MoreUserInterfaceControls
		     ├── iOSCodeObjectiveC
			      └── 4 More User Interface Fun

ASSIGNMENT A2: Refactor Following Code
	0. Follow Good Naming Conventions
	1. Incorporate Good Swift Design Practices
	2. Organise Code Better Way and Bring Better Designs
	3. Apply DRY [ Don't Repeat Yourself ]
	4. Change Deprecated APIs to Latest APIs
	5. Optimise View Hieraracy
	6. Implement Lazy Loading Pattern
	7. Clicking On Editable Text Box Should Show Software Keyboard

ASSIGNMENT A3: Extensive Reaading Assignment
	iOS Apple Guide Reading Assignment
		Read Selective Topics From
			Apple iPhone App Programming Guide.pdf

ASSIGNMENT A4: Reading and Coding Assignments
	Reference Book: 
		iOS Programming The Big Nerd Ranch Guide 7th Edition

	1. Read Chapter 01 to Chapter 05 From
	2. Code All The Examples In Chapter 01 To Chapter 05
	3. Solve Challenges In Chapter 01 To Chapter 05

ASSIGNMENT A5: Reference Material For Self Study [ ADVANCED ]
	https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/CocoaFundamentals/CocoaDesignPatterns/CocoaDesignPatterns.html


//____________________________________________________________________________
//
// DAY 08
//____________________________________________________________________________


Assignment A0: iOS Code Exploration and Reasoning Assignment
	Explore Following Code, Try To Reason The Code
		.
	StudyMaterial15.1
	└── iOSProgramming7E.Working
	    ├── 00-Resources
	    │ ├── ConvertIcon@2x.png
	    │ ├── ConvertIcon@3x.png
	    │ ├── Emoji Images
	    │ ├── MapIcon@2x.png
	    │ ├── MapIcon@3x.png
	    │ └── Project App Icons

	    ├── 01-Quiz
	    │ └── 01-Simple
	    
	    ├── 02-WordTrotter
	    │ ├── 03-View
	    │ ├── 04-ViewControllers
	    │ ├── 05-ProgrammaticViews
	    │ ├── 06-Delegation
	    │ └── 07-Localization
	    
	    ├── 03-LootLogger
	    │ ├── 09-TableViewControllers
	    │ ├── 10-TableViewCells
	    │ ├── 11-StackViews
	    │ ├── 12-NavigationController
	    │ ├── 13-Persistence
	    │ ├── 14-PresentingViewControllers
	    │ ├── 15-Camera
	    │ └── 16-AdaptiveInterfaces
	    
	    ├── 04-Mandala
	    │ ├── 17-ContainerViewControllers
	    │ ├── 18-Animations
	    │ └── 19-CustomControls
	    
	    └── 05-Photorama
	        ├── 20-WebServices
	        ├── 21-CollectionViews
	        ├── 22-CoreDataIntro
	        ├── 23-CoreDataRelationships
	        └── 24-Accessibility

Assignment A2: Reading, Experimentation and Coding Assignments
	Reference Book: 
		iOS Programming The Big Nerd Ranch Guide 7th Edition
		// Tutorial Style : To Do Approach  

	1. Read All Chapter 01 to Chapter 21
	2. Code and Experiment All Examples From Chapter 01 to Chapter 21
	3. Solve All Challenges From Chapter 01 to Chapter 21

Assignment A3: Extensive Reading Assignment [ APPLE GUIDES ]
	iOS Apple Guide Reading Assignment
		Read Selective Topics From
			AppleGuides - TextBook Style
			1. Apple iPhone App Programming Guide.pdf
			2. Apple Table View Controller Programming Guide.pdf
			3. Apple View Controller Programming Guide.pdf
			4. Apple Event Handling Guide For iOS.pdf

Assignment A4: Code All Examples PROGRAMMATICALLY  [ CODING ASSINGMENT ]
	1. Code All Examples From Chapter 01 to Chapter 21
			PROGRAMMATICALLY i.e. Without Storyboard/SwiftUI

Assignment A5: CODE CUSTOM NAVIGATION CONTROLLER  [ ADVANCED CODING ASSINGMENT ]
	Reference Book: 
		Apple View Controller Programming Guide.pdf

	Create Your Own NavigationController By Subclassing UIViewController
		Design Ownership, Data Exchange and Communication Architecture
		Utilise Responder Chain Design
		Target-Action Design
		Write With Good Space Complexity

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

https://github.com/amarjitlife/BajajFinserviOSJune2025
amarjitlife@gmail.com
+91 9980 777 145

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

