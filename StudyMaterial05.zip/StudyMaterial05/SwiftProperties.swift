
//____________________________________________________________________________

print("\n\nStructure Mutability and Immutability")

// Creating Type FixedLengthRange
//		Associative Type : Associates Multiple Types Data Together

struct FixedLengthRange {
	// Mutable Member Property
	var firstValue: Int
	// Immutable Member Property
	let length: Int
}

var rangeOfThreeItems = FixedLengthRange( firstValue: 0, length: 3 )

print( rangeOfThreeItems )
print( rangeOfThreeItems.firstValue )
rangeOfThreeItems.firstValue = 66

print( rangeOfThreeItems )
print( rangeOfThreeItems.firstValue )

let rangeOfThreeItemsAgain = FixedLengthRange( firstValue: 0, length: 3 )
print( rangeOfThreeItemsAgain )
// rangeOfThreeItemsAgain.firstValue = 66
// print( rangeOfThreeItemsAgain )

//____________________________________________________________________________

print("\n\nStructure With Default Values and Member Properties and Functions")
struct Point {
	var x = 0.0, y = 0.0
}

struct Size {
	var width = 0.0, height = 0.0
}

struct Rectangle {
	// Member Properties
	var origin 	= Point()
	var size 	= Size()
	// Member Function
	func getCenter() -> Point {
		let cx = origin.x + ( size.width / 2 )
		let cy = origin.y + ( size.height / 2 )
		return Point( x: cx, y: cy )
	}

	mutating func setCenter( newCenter: Point ) {
		origin.x = newCenter.x - ( size.width / 2 )
		origin.y = newCenter.y - ( size.height / 2 )
	}
}


var rectangle = Rectangle( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )

print( rectangle )
print( rectangle.origin )
print( rectangle.size )
print( rectangle.getCenter() )


//____________________________________________________________________________

print("\n\nStructure With: Computed Properties")

struct RectangleAgain {
	// Member Properties : Stored Member Properties
	var origin 	= Point()
	var size 	= Size()

	// Member Properties : Computed Member Properties
	var center : Point {	
		get { // Custom Getter
			print("center Getter Called...")
			let cx = origin.x + ( size.width / 2 )
			let cy = origin.y + ( size.height / 2 )
			return Point( x: cx, y: cy )
		}

		set( newCenter ) { // Custom Setter
			print("center Setter Called...")
			let cx = newCenter.x - ( size.width / 2 )
			let cy = newCenter.y - ( size.height / 2 )
			origin = Point( x: cx, y: cy ) 
		}
	}
}

var rectangle1 = RectangleAgain( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )
print( rectangle1 )
print( rectangle1.size )
print( rectangle1.origin )
print( rectangle1.center ) // rectangle1.get()

rectangle1.center = Point( x: 50.0, y: 50.0 ) // rectanlge1.set(Point(x: 50.0, y: 50.0))

print( rectangle1.origin )
print( rectangle1.center )

//____________________________________________________________________________

// Stored Properties
// 		In its simplest form, a stored property is a constant or variable 
//		that’s stored as part of an instance of a particular class or structure. 
//		Stored properties can be either variable stored properties 
//		(introduced by the var keyword) or constant stored properties 
//		(introduced by the let keyword).

//	Computed Properties
//		In addition to stored properties, classes, structures, and enumerations 
//		can define computed properties, which don’t actually store a value. 
//		Instead, they provide a getter and an optional setter to retrieve and 
//		set other properties and values indirectly.

//____________________________________________________________________________

print("\n\nStructure With: Computed Properties Shorthand Setter")

struct RectangleOnceAgain {
	// Member Properties : Stored Member Properties
	var origin 	= Point()
	var size 	= Size()

	// Member Properties : Computed Member Properties
	var center : Point {	
		get { // Custom Getter
			print("center Getter Called...")
			let cx = origin.x + ( size.width / 2 )
			let cy = origin.y + ( size.height / 2 )
			return Point( x: cx, y: cy )
		}

		set { // Custom Setter
			print("center Setter Called...")
			let cx = newValue.x - ( size.width / 2 )
			let cy = newValue.y - ( size.height / 2 )
			origin = Point( x: cx, y: cy ) 
		}
	}
}

var rectangle2 = RectangleOnceAgain( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )
print( rectangle2 )
print( rectangle2.size )
print( rectangle2.origin )
print( rectangle2.center ) // rectangle2.get()

rectangle2.center = Point( x: 50.0, y: 50.0 ) // rectanlge2.set(Point(x: 50.0, y: 50.0))

print( rectangle2.origin )
print( rectangle2.center )


//____________________________________________________________________________

print("\n\nStructure With: Computed Properties Shorthand Getter")

// Shorthand Getter Declaration
// 		If the entire body of a getter is a single expression, 
//		the getter implicitly returns that expression

struct RectangleOnceMore {
	// Member Properties : Stored Member Properties
	var origin 	= Point()
	var size 	= Size()

	// Member Properties : Computed Member Properties
	var center : Point {	
		get { // Custom Getter Without return Keyword
			// print("center Getter Called...")
			Point( x: origin.x + ( size.width / 2 ),   
				   y: origin.y + ( size.height / 2 ) )
		}

		set { // Custom Setter
			print("center Setter Called...")
			let cx = newValue.x - ( size.width / 2 )
			let cy = newValue.y - ( size.height / 2 )
			origin = Point( x: cx, y: cy ) 
		}
	}
}

var rectangle3 = RectangleOnceMore( origin: Point(x: 0.0, y: 0.0),
						   size : Size( width: 10, height: 20 ) )
print( rectangle3 )
print( rectangle3.center ) // rectangle2.get()

rectangle3.center = Point( x: 50.0, y: 50.0 ) // rectanlge2.set(Point(x: 50.0, y: 50.0))

print( rectangle3 )
print( rectangle3.center )

//____________________________________________________________________________

print("\n\nReadonly Properties")

struct Cuboid {
	var width = 0.0, height = 0.0, depth = 0.0
	// error: 'let' declarations cannot be computed properties
	// let volume: Double {
	var volume: Double { // Design Choice 01
		get {
			return width * height * depth
		}
	}
}

let someCuboid = Cuboid(width: 10.0, height: 11.0, depth: 10.0 )
print( someCuboid )

let someCuboidVolume = someCuboid.volume
print( someCuboidVolume )

// error: cannot assign to property: 'volume' is a get-only property
// someCuboid.volume = 999
// print( someCuboidVolume )

//____________________________________________________________________________

print("\n\nReadonly Computed Properties")

struct CuboidAgain {
	var width = 0.0, height = 0.0, depth = 0.0
	// error: 'let' declarations cannot be computed properties
	// let volume: Double {
	var volume: Double { // This Is By Default Getter Code
		return width * height * depth
	}
}

var someCuboid1 = CuboidAgain(width: 10.0, height: 11.0, depth: 10.0 )
print( someCuboid1 )

print( "Volume: ", someCuboid1.volume )

// error: cannot assign to property: 'volume' is a get-only property
// someCuboid1.volume = 999
// print( someCuboidVolume1 )

print( "Width:", someCuboid1.width ) 
someCuboid1.width = 99.0
print( "Width:", someCuboid1.width )
print( "Volume: ", someCuboid1.volume )

//____________________________________________________________________________

// Read-Only Computed Properties
//		A computed property with a getter but no setter is known as 
//		a read-only computed property. A read-only computed property 
//		always returns a value, and can be accessed through dot syntax, 
//		but can’t be set to a different value.

// Note
// 		You must declare computed properties 
//		— including read-only computed properties — as variable properties 
//		with the var keyword, because their value isn’t fixed. 
//		The let keyword is only used for constant properties, to indicate 
//		that their values can’t be changed once they’re set as part of 
//		instance initialization.

//	You can simplify the declaration of a read-only computed property 
//	by removing the get keyword and its braces:

//____________________________________________________________________________

print("\n\nProperty Observers Member Functions")

class StepCounter {
	var totalSteps: Int = 0 {
		// Property Observers
		willSet( newTotalSteps ) { // It Will Called Before Setter Called
			print("New Total Steps: ", newTotalSteps )
		}

		didSet { // This Will Called After Setter Called
			if totalSteps > oldValue {
				print("Added Steps: ", totalSteps - oldValue )
			}
		}
	}
}


let counter = StepCounter()

print( counter.totalSteps ) // couter.getTotalSteps()
counter.totalSteps = 999	// counter.setTotalSteps( 99 )
print( counter.totalSteps ) // couter.getTotalSteps()


//____________________________________________________________________________

struct Achievement {
	var id: Int = 0
	var name: String = "Unknown"
	var progressRate: Double = 0.0 {
		didSet { // Proerty Observer
			let allowedRange: ClosedRange<Double> = 0...1
			// Validation Logic
			if allowedRange.contains( progressRate ) {
				return
			}

			print("Progress Rate Must Be Within 0.0 to 1.0")
			// assertionFailure("Progress Rate Must Be Within 0.0 to 1.0")
			progressRate = max( allowedRange.lowerBound, progressRate )
			progressRate = min( allowedRange.upperBound, progressRate )
		}
	}
}

var achieve = Achievement()
print( achieve )

print( "Progress Rate:", achieve.progressRate )
achieve.progressRate = 0.8
print( "Progress Rate:", achieve.progressRate )

achieve.progressRate = 9.9 // Triggers Validation Logic
print( "Progress Rate:", achieve.progressRate )


//____________________________________________________________________________

// Property Observers
// 		Property observers observe and respond to changes in a property’s value. 
//		Property observers are called every time a property’s value is set, 
//		even if the new value is the same as the property’s current value.

// You can add property observers in the following places:
// 		Stored properties that you define
// 		Stored properties that you inherit
//		Computed properties that you inherit

//		For an inherited property, you add a property observer by overriding 
//		that property in a subclass. 

//		For a computed property that you define, use the property’s setter 
//		to observe and respond to value changes, instead of trying 
//		to create an observer. 

// You have the option to define either or both of these observers on a property:

//		willSet is called just before the value is stored.
//		didSet is called immediately after the new value is stored.

//____________________________________________________________________________

print("\n\nStructures: Instance And Type Member Properties!")

// Definining Type SomeStructure
//		Having Two Properties
struct SomeStructure {
	// Instance Member Properties: Are Non Static Properties
	var instanceStoredProperty: String = "Undefined"
	var instanceComputedProperty: String {
		get {
			return "Instance Computed Property"
		}
	}

	// Type Member Properties : Are Static Properties Using static Keyword
	static var storedTypeProperty 	= "Stored Type Property"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property" 
		}
	}
}

// gabbar Is Instance Of Type SomeStructure
let gabbar = SomeStructure( instanceStoredProperty: "Gabbar Singh" )
print( gabbar )
print( gabbar.instanceStoredProperty )
print( gabbar.instanceComputedProperty )

//  error: instance member 'instanceStoredProperty' cannot be used on type 'SomeStructure'
// print( SomeStructure.instanceStoredProperty )
// error: instance member 'instanceComputedProperty' cannot be used on type 'SomeStructure'
// print( SomeStructure.instanceComputedProperty )\

print( SomeStructure.storedTypeProperty )
print( SomeStructure.computedTypeProperty )

// error: static member 'storedTypeProperty' cannot be used on instance of type 'SomeStructure'
// print( gabbar.storedTypeProperty )
// error: static member 'computedTypeProperty' cannot be used on instance of type 'SomeStructure'
// print( gabbar.computedTypeProperty )


//____________________________________________________________________________

print("\n\nEnumeration: Instance And Type Member Properties!")

enum SomeEnumeration {
	// Instance Member Properties: Are Non Static Properties
	// error: enums must not contain stored properties
	// var instanceStoredProperty: String = "Undefined"
	var instanceComputedProperty: String {
		get {
			return "Instance Computed Property"
		}
	}

	// Type Member Properties : Are Static Properties Using static Keyword
	static var storedTypeProperty 	= "Stored Type Property"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property" 
		}
	}
}

// error: 'SomeEnumeration' cannot be constructed because it has no accessible initializers
// let gabbar1 = SomeEnumeration()
// print( gabbar1 )
// print( gabbar1.instanceStoredProperty )
// print( gabbar1.instanceComputedProperty )

// error: instance member 'instanceComputedProperty' cannot be used on type 'SomeEnumeration'; 
// did you mean to use a value of this type instead?
// print( SomeEnumeration.instanceComputedProperty )

print( SomeEnumeration.storedTypeProperty )
print( SomeEnumeration.computedTypeProperty )

//____________________________________________________________________________

print("\n\nClasses: Instance And Type Member Properties!")

class SomeClass {
	// Instance Member Properties: Are Non Static Properties
	var instanceStoredProperty: String = "Undefined"
	var instanceComputedProperty: String {
		get {
			return "Instance Computed Property"
		}
	}

	// Type Member Properties : Are Static Properties Using static Keyword
	static var storedTypeProperty 	= "Stored Type Property"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property" 
		}
	}

    class var overrideableComputedTypeProperty: Int {
        return 777
    }
}


// gabbar Is Instance Of Type SomeClass
let gabbar2 = SomeClass()
print( gabbar2 )
print( gabbar2.instanceStoredProperty )
print( gabbar2.instanceComputedProperty )

print( SomeClass.storedTypeProperty )
print( SomeClass.computedTypeProperty )
print( SomeClass.overrideableComputedTypeProperty )

//____________________________________________________________________________

// Type Property Syntax
// 		In C and Objective-C, you define static constants and variables 
//		associated with a type as global static variables. 

//		In Swift, however, type properties are written as part of the type’s 
//		definition, within the type’s outer curly braces, and each type property 
//		is explicitly scoped to the type it supports.

//		You define type properties with the static keyword. 
//		For computed type properties for class types, you can use the class keyword 
//		instead to allow subclasses to override the superclass’s implementation. 


//____________________________________________________________________________
// BAD DESIGN

// THINK ABOUT IT!
//		Is Static Really Required In This Code?
//		Can We Design Following Code Without static Members?

struct AudioChannel {
    static let thresholdLevel = 10
    static var maxInputLevelForAllChannels = 0

    var currentLevel: Int = 0 {
        didSet {
            if currentLevel > AudioChannel.thresholdLevel {
                // cap the new audio level to the threshold level
                currentLevel = AudioChannel.thresholdLevel
            }
            if currentLevel > AudioChannel.maxInputLevelForAllChannels {
                // store this as the new overall maximum input level
                AudioChannel.maxInputLevelForAllChannels = currentLevel
            }
        }
    }
}

//____________________________________________________________________________

print("\n\nLazy Loading Pattern...")

// DESIGN PRINCIPLES
//		1. DESIGN TOWARDS NON NULLABILITY RAHTER THAN NULLABILITY
//		2. INTRODUCED NULLABILITY ONLY ON SOLID REASONING/REQUIREMENT
//		3. HANDLE NULLABILITY AS EARLY AS POSSIBLE
//		4. DON'T PROPOGATE NULLABILITY IF NOT REQUIRED

class DataImporter {
	var filename = "SomeDataFile.json"
	init( ) {
		print("DataImporter Initialiser Called...")
	}
}

class DataManager {
	// lazy var importer = DataImporter()
	// Compiler Will Generate Following Code For Above lazy Line Of Code
	// private var _importer: DataImporter = DataImporter()	
	private var _importer: DataImporter? // NULLABLE
	// var importer: DataImporter? {
	var importer: DataImporter {
			get {
				if _importer == nil {
					_importer = DataImporter()
				}
				return _importer!  // SENDING NON NULLABLE
			}
	}
	var data = [String]() // Load This Data From DB/Files

	init( ) {
		print("DataManager Initialiser Called...")
	}
}

let manager =  DataManager()

// print( manager.importer?.filename  ?? "Uknown File")
// if manager.importer != nil {
// 	print( manager.importer!.filename )
// } else {
// 	print("Importer Doesn't Exists")
// } 

print( manager.importer.filename )
// Loading Data From Somewhere...
manager.data += ["Some Data"]
manager.data += ["Some More Data"]
// print( manager.data )

// Lazy Loading Pattern...
// DataImporter Initialiser Called...
// DataManager Initialiser Called...
// SomeDataFile.json

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codeshare.io/GqnNNX
// https://codeshare.io/GqnNNX
// https://codeshare.io/GqnNNX



