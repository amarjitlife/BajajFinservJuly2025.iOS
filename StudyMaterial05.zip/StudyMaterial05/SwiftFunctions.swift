
//____________________________________________________________________________

// Takes 1 Argument and Return String Value
func sayHello( personName: String ) -> String {
	let greeting = "Hello, " + personName + "!"
	return greeting
}

// error: missing argument label 'personName:' in call
// print( sayHello("Asywarya Rai") )

print( sayHello( personName: "Asywarya Rai") )
print( sayHello( personName: "Sharukh Khan") )

func hello() {
	print("Good Morning!")
}

let some: () = hello()
// warning: constant 'some' inferred to have type '()', which may be unexpected
print( some )

//____________________________________________________________________________

func halfOpenRangeLength( start: Int, end: Int ) -> Int {
	return end - start
}

print( halfOpenRangeLength( start: 1, end: 11 ) )

//____________________________________________________________________________

func minMax( numbers: [Int] ) -> (min: Int, max: Int) {
	var currentMin = numbers[0]
	var currentMax = numbers[0]

	for number in numbers[1..<numbers.count] {
		if number > currentMax {
			currentMax = number
		} else if number < currentMin {
			currentMin = number
		}
	}

	return ( currentMin, currentMax )
}

let bounds = minMax( numbers: [10, 20, -99, 100, 99, 200, 30 ] )
print( bounds )
print( bounds.0, bounds.1 )
print( bounds.min, bounds.max )

let bounds1 = minMax( numbers: [11, 22, -99, 100, 99, 211, 3000 ] )
print( bounds1 )
print( bounds1.0, bounds1.1 )
print( bounds1.min, bounds1.max )

//____________________________________________________________________________

func someFunction( externalParameterName localParameterName: Int ) {
	let result = localParameterName + 100
	print( result )
}

someFunction( externalParameterName : 99 )

// Libarary
// join Function Coming From External Library
func join(s1: String, s2: String, joiner: String ) -> String {
	return s1 + joiner + s2 
}

var joinedString = join( s1: "Hello", s2: "World", joiner: " " )
print( joinedString )

// Our API As Our Naming Convention
func join( string s1: String, toString s2: String, withJoiner joiner: String ) -> String {
	// Using External Library Function
	//		Hiding The API
	return join( s1: s1, s2: s2, joiner: joiner )
}

/// Developer Should Use Our API
joinedString = join( string: "Hello", toString: "World", withJoiner: " " )
print( joinedString )

//____________________________________________________________________________

// Shorthand External Parameter Names
func containsCharacter(string: String, characterToFind: Character) -> Bool {
    for character in string {
        if character == characterToFind {
            return true
        }
    }
    return false
}

let containsAVee = containsCharacter(string: "aardvark", characterToFind: "v")
print( containsAVee )

//____________________________________________________________________________

// Polymorphism Function
// Using Mechanism : Function Overloading
//		1. Number Of Arguments
//		2. Types Of Arguments
//		3. Parameter Names
func join( first: String, second: String ) -> String { 
	return first + "  " + second
}

func join( other: String, another: String ) -> String { 
	return other + "  " + another
}

func join( first: String, second: String, joiner: String ) -> String { 
	return first + joiner + second
}

joinedString = join( first: "Hello", second: "World" )
print( joinedString )

joinedString = join( other: "Hello", another: "World" )
print( joinedString )

joinedString = join( first: "Hello", second: "World", joiner: " " )
print( joinedString )


//____________________________________________________________________________

// Polymorphism Function
// Using Mechanism : Default Arguments
func joinAgain( first: String, second: String, joiner: String = " " ) -> String { 
	return first + joiner + second
}

joinedString = joinAgain( first: "Hello", second: "World" )
print( joinedString )

joinedString = joinAgain( first: "Hello", second: "World", joiner: "##" )
print( joinedString )

// DESIGN PRACTICE
//		Polymorphic Function
//			Always Prefer Function With Default Arguments
//				Over Function Overloading

//____________________________________________________________________________

// Polymorphism Function
// Using Mechanism : Varidiac Arguments 
///				Variable Number Of Arguments
//						
func arithmaticMean( numbers: Double... ) -> Double {
	var total: Double = 0
	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

print( arithmaticMean( numbers: 10, 20, 30, 40, 50) )
print( arithmaticMean( numbers: 10, 20, 30) )
print( arithmaticMean( numbers: 2, 3, 4, 5) )

//____________________________________________________________________________

func alignRight( string: String, totalLength: Int, pad: Character ) -> String {
	var padding : String = ""
	let amountToPad = totalLength - string.count
	if amountToPad < 1 {
		return string
	}

	let padString = String( pad )
	for _ in 1...amountToPad {
		padding = padString + padding
	}
	
	// error: cannot assign to value: 'string' is a 'let' constant
	// string = padding + string
	// return string
	return padding + string 
}

let originalSgtring = "Hello"
let paddedString = alignRight( string: originalSgtring, totalLength: 20, pad: "-" )
print( originalSgtring )
print( paddedString )

// DESIGN PRINCPLE
//		DESIGN TOWARDS IMMUTABLITY RATHER THAN TOWARDS MUTABILITY

//____________________________________________________________________________

func swap( a : Int, b: Int ) {
	var a = a // local is Shadowing Parameter
	var b = b
	let temp = a
	a = b 		// error: cannot assign to value: 'a' is a 'let' constant
	b = temp 	// error: cannot assign to value: 'b' is a 'let' constant
}

// inout Means Pass By Reference
func swapAgain( a : inout Int, b: inout Int ) {
	let temp = a
	a = b 		// error: cannot assign to value: 'a' is a 'let' constant
	b = temp 	// error: cannot assign to value: 'b' is a 'let' constant
}

var x = 100
var y = 200

print(x, y )
swap(a: x, b: y)
print(x, y )

swapAgain(a: &x, b: &y)
print(x, y )

//____________________________________________________________________________

// Function Type
//		(Int, Int) -> Int
func sum( a: Int, b: Int ) -> Int { return a + b }
func sub( a: Int, b: Int ) -> Int { return a - b }
func mul( a: Int, b: Int ) -> Int { return a * b }

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int

// Polymorphic Function
// Higher Order Functions
//		Function Which Can Take and/or Return Functions
func calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation( a, b )
}

func playWithCalculator() {
	let a = 200, b = 100

	var result: Int
	result = calculator( a: a, b: b, operation: sum )
	print( "Result : ", result )

	result = calculator( a: a, b: b, operation: sub )
	print( "Result : ", result )

	result = calculator( a: a, b: b, operation: mul )
	print( "Result : ", result )

	// error: cannot convert value of type '(Int, Int) -> Int' to specified type 'Int'
	let something: (Int, Int) -> Int = sum
	result = something(100, 11)
	print( "Result : ", result )

	let somethingAgain: (Int, Int, (Int, Int) -> Int ) -> Int = calculator
	print( somethingAgain )

	result = calculator(a: a, b: b, operation: { (x: Int, y: Int) -> Int in return x + y } )
	print( "Result : ", result )

	result = calculator(a: a, b: b, operation: { (x, y) in return x + y } )
	print( "Result : ", result )

	result = calculator(a: a, b: b, operation: { (x, y) in x + y } )
	print( "Result : ", result )

	result = calculator(a: a, b: b, operation: { $0 + $1 } )
	print( "Result : ", result )

	result = calculator(a: a, b: b, operation: + )
	print( "Result : ", result )

	result = calculator(a: a, b: b) { // Trailing Lambda Syntax
		(x, y) in x + y 
	}

	print( "Result : ", result )

}

playWithCalculator()

//____________________________________________________________________________

// Function Types as Return Types

func stepForward(input: Int) -> Int {
    return input + 1
}

func stepBackward(input: Int) -> Int {
    return input - 1
}

func chooseStepFunction(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}

func playWithChooseStep() {
	let something: (Bool) -> (Int) -> Int = chooseStepFunction
	let somethingAgain: (Int) -> Int = something( true )
	print( somethingAgain, something )
}

//____________________________________________________________________________

// >>> tt = (10, "Ding")
// >>> mm = ("Dong", 11)
// >>> tt = mm
// >>> tt
// ('Dong', 11)

var tt = (10, "Ding")
let mm = ("Dong", 11)

// error: cannot assign value of type '(String, Int)' to type '(Int, String)'
// tt = mm  

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codeshare.io/2WLxq8
// https://codeshare.io/2WLxq8
// https://codeshare.io/2WLxq8

