
//____________________________________________________________________________

// Methods
// 		Instance Methods

class Counter {
    var count = 0
    
    func increment() {
        count = count + 1
    }
    
    func incrementBy(amount: Int) {
        count += amount
    }
    
    func reset() {
        count = 0
    }
}

let counter = Counter()
counter.increment()
counter.incrementBy(amount: 5)
counter.reset()

//____________________________________________________________________________


// amount is a local name only.
// numberOfTimes is both a local and external name

class CounterTwo {
	// Instance Member Property: Instance Property
    var count: Int = 0
    // Instance Member Function: Instance Method
    func incrementBy(amount: Int, numberOfTimes: Int) {
        count += amount * numberOfTimes
    }
}

let counter2 = CounterTwo()
counter2.incrementBy(amount: 5, numberOfTimes:3)

//____________________________________________________________________________

// Assigning to self Within a Mutating Method

struct Point {
	var x = 0.0, y = 0.0

	func isToTheRightOfX( x : Double ) -> Bool {
		return self.x > x
	}

	// func moveByX( deltaX: Double, deltaY: Double ) {
	mutating func moveByX( deltaX: Double, deltaY: Double ) {
		// error: cannot assign to property: 'self' is immutable
		self.x = self.x + deltaX
		self.y = self.y + deltaY
	}
}

// let somePoint = Point( x: 10.0, y: 20.0 )
// error: cannot use mutating member on immutable value: 'somePoint' is a 'let' constant

var somePoint = Point( x: 10.0, y: 20.0 )
print( somePoint )
print( somePoint.isToTheRightOfX(  x: 1.0 ) )

somePoint.moveByX( deltaX: 10.0, deltaY: 10.0 )
print( somePoint )

//____________________________________________________________________________

enum TriStateSwitch {
	case off, low, mid, high

	// func next() {
	mutating func next() {
		switch self {
			case .off:
				self = .low
			case .low:
				self = .mid
			case .mid:
				self = .high
			case .high:
				self = .off
		}
	}
}

var ovenSwitch = TriStateSwitch.off

print( ovenSwitch )
ovenSwitch.next()
print( ovenSwitch )
ovenSwitch.next()
print( ovenSwitch )
ovenSwitch.next()
print( ovenSwitch )

//____________________________________________________________________________

struct LevelTracker {
    static var highestUnlockedLevel = 1

    static func unlockLevel(level: Int) {
        if level > highestUnlockedLevel { highestUnlockedLevel = level }
    }

    static func levelIsUnlocked(level: Int) -> Bool {
        return level <= highestUnlockedLevel
    }

    var currentLevel = 1
    mutating func advanceToLevel(level: Int) -> Bool {
        if LevelTracker.levelIsUnlocked(level: level) {
            currentLevel = level
            return true
        } else {
            return false
        }
    }
}

class Player {
    var tracker = LevelTracker()
    let playerName: String

    func completedLevel(level: Int) {
        LevelTracker.unlockLevel(level: level + 1)
        let _ = tracker.advanceToLevel(level: level + 1)
    }

    init(name: String) {
        playerName = name
    }
}

var player = Player(name: "Argyrios")
player.completedLevel(level: 1)
print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")

player = Player(name: "Beto")
if player.tracker.advanceToLevel(level: 6) {
    print("player is now on level 6")
} else {
    print("level 6 has not yet been unlocked")
}

// HOME WORK
// HOME WORK
// HOME WORK

// REFACTOR ABOVE CODE TO DO BETTER DESIGN

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codeshare.io/GqnNNX
// https://codeshare.io/GqnNNX
// https://codeshare.io/GqnNNX



