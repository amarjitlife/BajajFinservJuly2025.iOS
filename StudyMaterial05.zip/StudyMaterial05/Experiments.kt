
//__________________________________________________________

fun hello() {
	println("Good Morning!")
}

fun sayhello(toName: String ) {
	println("Good Morning! $toName")
}

fun playWithHello() {
	val some = hello()
	println( some )

	sayhello( "Gabbar Singh" )
	sayhello( toName = "Gabbar Singh" )	
}

//__________________________________________________________
//__________________________________________________________

fun sum( a: Int, b: Int ) : Int {
	return a + b
}

fun sumAgain( a: Int, b: Int ) = a + b

fun playWithFunctions() {
	var result = sum( 100, 111 )

	println("Result : $result")

	result = sumAgain( 100, 111 )
	println("Result : $result")
}


//__________________________________________________________


interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

// error: type checking has run into a recursive problem. 
//		Easiest workaround: specify the types of your declarations explicitly.
// fun evaluate( e: Expr ) : Int = when( e ) {
fun evaluate( e: Expr ) : Int {
	return when( e ) {
		is Num 	-> e.value
		is Sum 	-> evaluate( e.left ) + evaluate( e.right )
		else	-> throw IllegalArgumentException("Unknown Expression!")
	}
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num(200 )) ))	
	// ( 100 + 200 ) + 1000
	println( evaluate( Sum( Sum( Num(100), Num(200 )), Num(1000) ) ) )
}


//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

fun main() {
	println("\nFunction: playWithHello")
	playWithHello()

	println("\nFunction: playWithFunctions")
	playWithFunctions()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

