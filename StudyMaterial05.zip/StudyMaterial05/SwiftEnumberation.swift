
//____________________________________________________________________________
// CompassPoint Type
//		Operation
//		Range = { North, South, East, West }
enum CompassPoint {
	case North
	case South
	case East
	case West
}

enum Planet {
	case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

var directionToHead = CompassPoint.West
print( directionToHead )

directionToHead = .East
print( directionToHead )

directionToHead = .West

// directionToHead Is Of Type CompassPoint
//		Type Safe Expression
//		Respecting Type Like A God!
switch directionToHead {
case .North:
	print("Let's Go North!")
case .South:
	print("Let's Go! South")
case .East:
	print("Let's Go! East")
case .West:
	print("Let's Go! West")
// default:
// 	print("Let's Go! Default")	
}

// SwiftEnumberation.swift:23:1: error: switch must be exhaustive
// 21 | directionToHead = .South
// 22 | 
// 23 | switch directionToHead {
//    | |- error: switch must be exhaustive
//    | `- note: add missing case: '.West'

//____________________________________________________________________________

// Associative Enums/Values
enum Barcode {
	case UPCA(Int, Int, Int)
	case QRCode(String)
}

let productBarCode = Barcode.UPCA(11, 22222999_11, 333)
print( productBarCode )

let qrCode = Barcode.QRCode("fokoefoe-54-504-")
print( qrCode )

var something: Barcode
something = productBarCode
print( something )

something = qrCode
print( something )

switch productBarCode {
	//Using let Binding Associative Values To Specific Identifier
	case .UPCA(let numberSystem, let identifier, let check):
		print(numberSystem, identifier, check )
	case .QRCode(let productCode):
		print(productCode)
}

// Shortcut Syntax For The Above Code
switch productBarCode {
	//Using let Binding Associative Values To Specific Identifier
	case let .UPCA(numberSystem, identifier, check):
		print(numberSystem, identifier, check )
	case let .QRCode(productCode):
		print(productCode)
}

//____________________________________________________________________________

enum Colour {
	case RED, GREEN, BLUE
}

struct ColourComponets {
	let r: UInt8
	let g: UInt8
	let b: UInt8
	let a: UInt8
}

let colourChoice = Colour.RED

switch colourChoice {
case .RED:
	print( ColourComponets(r: 200, g: 100, b: 100, a: 255) )
case .GREEN:
	print( ColourComponets(r: 10 , g: 240, b: 100, a: 255) )
case .BLUE:
	print( ColourComponets(r: 10, g: 10, b: 200, a: 255) )
}

//____________________________________________________________________________

enum Color {
	case RED(Int, Int, Int, Int)
	case GREEN(Int, Int, Int, Int)
	case BLUE(Int, Int, Int, Int)
}

let colorChoice = Color.RED(200, 100, 100, 255)

switch colorChoice {
	case .RED(let r, let g, let b, let a):
		print(r, g, b, a)
	case .GREEN(let r, let g, let b, let a):
		print(r, g, b, a)
	case .BLUE(let r, let g, let b, let a):
		print(r, g, b, a)
}

//____________________________________________________________________________

print( Colour.RED ) // RED
print( Colour.GREEN ) // GREEN

//____________________________________________________________________________
// Raw Values

enum PlanetAgain : Int {
	case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

print( PlanetAgain.Mercury )
print( PlanetAgain.Earth )

print( PlanetAgain.Mercury.rawValue )
print( PlanetAgain.Earth.rawValue )

let possiblePlanet: PlanetAgain? = PlanetAgain( rawValue: 777 )

// print( possiblePlanet )
// print( possiblePlanet.rawValue )

if let somePlanet = possiblePlanet {
	switch somePlanet {
	case .Earth:
		print("Earth")
	default:
		print("Default")
	}
} else {
	print("Nothiness Found: Dealing with RawValues")
}


//____________________________________________________________________________

// Raw Values
enum ASCIIControlCharacter : Character {
    case Tab = "\t"
    case LineFeed = "\n"
    case CarriageReturn = "\r"
}

print( ASCIIControlCharacter.Tab )
print( ASCIIControlCharacter.LineFeed )
print( ASCIIControlCharacter.CarriageReturn )

print( ASCIIControlCharacter.Tab.rawValue )
print( ASCIIControlCharacter.LineFeed.rawValue )
print( ASCIIControlCharacter.CarriageReturn.rawValue )

//____________________________________________________________________________

var somethingAgain: Int = 11
print( somethingAgain )

// somethingAgain = PlanetAgain.Mercury
// error: cannot assign value of type 'PlanetAgain' to type 'Int'
// print( somethingAgain )

// In Swift
//		Enums Are Type Safe

// In C/C++
//		Enums Are Not Type Safe

// BEST PRACTICE
//		Always Prefer Swift Enums Without rawValues

//____________________________________________________________________________
// Recursive Enumerations

/*
enum ArithmeticExpression {
    case Number(Int)
    indirect case Addition(ArithmeticExpression, ArithmeticExpression)
    indirect case Multiplication(ArithmeticExpression, ArithmeticExpression)
}

indirect enum ArithmeticExpression2 {
    case Number(Int)
    case Addition(ArithmeticExpression2, ArithmeticExpression2)
    case Multiplication(ArithmeticExpression2, ArithmeticExpression2)
}

func evaluate(expression: ArithmeticExpression) -> Int {
    switch expression {
    case .Number(let value):
        return value
    case let .Addition(lhs, rhs):
        return evaluate(lhs) + evaluate(rhs)
    case let .Multiplication(lhs, rhs):
        return evaluate(lhs) * evaluate(rhs)
    }
}

let five = ArithmeticExpression.Number(5)
let four = ArithmeticExpression.Number(4)
let sum = ArithmeticExpression.Addition(five, four)
let product = ArithmeticExpression.Multiplication(sum, ArithmeticExpression.Number(2))
print(evaluate(product))
*/

//____________________________________________________________________________
// Recursive Enumerations
// enum ArithmeticExpression {
//     case number(Int)
//     // |      `- error: recursive enum 'ArithmeticExpression' is not marked 'indirect'
//     case addition(ArithmeticExpression, ArithmeticExpression)
//     case multiplication(ArithmeticExpression, ArithmeticExpression)
// }

enum ArithmeticExpression {
    case number(Int)
    indirect case addition(ArithmeticExpression, ArithmeticExpression)
    indirect case multiplication(ArithmeticExpression, ArithmeticExpression)
}

let five = ArithmeticExpression.number(5)
let four = ArithmeticExpression.number(4)
let sum = ArithmeticExpression.addition(five, four)
let product = ArithmeticExpression.multiplication(sum, ArithmeticExpression.number(2))

func evaluate( _ expression: ArithmeticExpression) -> Int {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}

print( evaluate( product ) )


//____________________________________________________________________________

// Weekday Type
//		Operation = { dayType, letsParty }
//		Range = { Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday }

// Enums Can Have Member Functions, Member Computed Properties
enum Weekday {
    case Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday

    func dayType() -> String {
        switch self {
        case .Sunday, .Saturday:
            return  "Weekend"
        default:
            return "Weekday"
        }
     }

    var letsParty: String {
        self == .Saturday || self == .Sunday ? "Let's Party!!!" : "Uuufff!!! So Much Work!"
    }
}

print( Weekday.Monday.dayType() )
// this will return "Weekday"
print( Weekday.Sunday.dayType() )
// this will return "Weekend"
print( Weekday.Monday.letsParty )
print( Weekday.Saturday.letsParty )

//____________________________________________________________________________

enum MediaType: CaseIterable {
    case tvShows
    case movies

    var title: String {
        switch self {
        case .tvShows:
            return "TV Shows"
        case .movies:
            return "Movies"
        }
    }

    var description: String {
        switch self {
        case .tvShows:
            return "Watch the best TV Shows here"
        case .movies:
            return "Watch the best Movies here"
        }
    }
}

//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________
//____________________________________________________________________________

// https://codeshare.io/5ePVrJ
// https://codeshare.io/5ePVrJ
// https://codeshare.io/5ePVrJ

